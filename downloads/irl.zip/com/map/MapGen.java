package com.map;

import com.entities.*;
import java.awt.Color;
import java.util.*;

public class MapGen {
    public MapGen(long seed) {}
    public List<BaseEntity> generateSpawnRegion() {
        List<BaseEntity> world = new ArrayList<>();
        // 3D Grass Blocks (Wide and flat)
        for (int x = -5; x <= 5; x++) {
            for (int z = -5; z <= 5; z++) {
                world.add(new BaseEntity("Grass", x * 4, 0, z * 4, new Color(0, 100, 0), 3.0, 0.5, 3.0) {});
            }
        }
        // 3D Humans
        world.add(new Human("Alari", 0, -5, 0));
        return world;
    }
}