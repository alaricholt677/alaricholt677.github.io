# Flask emulator package
# Preserves Python indentation and adds Flask runtime.

import re


PLUGIN_IMPORT_RE = re.compile(
    r"^\s*import\s+Flask\s*;\s*$",
    re.IGNORECASE
)


def convert(text: str) -> str:
    lines = text.splitlines()

    body_lines = []

    for line in lines:
        raw = line.rstrip("\n")

        # Remove only the emulator plugin import:
        # import Flask;
        if PLUGIN_IMPORT_RE.match(raw):
            continue

        # Preserve blank lines
        if raw.strip() == "":
            body_lines.append("")
            continue

        # Preserve indentation exactly
        body_lines.append(raw)

    body = "\n".join(body_lines).strip("\n")

    out = []

    has_flask_import = (
        "from flask import" in body
        or "import flask" in body
    )

    has_app = "app = Flask(" in body

    if not has_flask_import:
        out.append(
            "from flask import Flask, request, jsonify, render_template_string, send_from_directory"
        )

    if not has_app:
        out.append("")
        out.append("app = Flask(__name__)")

    if body:
        out.append("")
        out.append(body)

    if (
        'if __name__ == "__main__"' not in body
        and "if __name__ == '__main__'" not in body
    ):
        out.append("")
        out.append('if __name__ == "__main__":')
        out.append("    app.run(host='0.0.0.0', port=5000, debug=False)")

    return "\n".join(out)


def combine(text: str) -> str:
    return text.strip() + "\n"