package com.circus.entities;

import java.awt.Color;
import java.util.ArrayList;

public class Gangle extends Entity { // MUST BE 'Gangle'
    public Gangle(String name, double x, double z) {
        super(name, new Color(240, 200, 160), x, z); 
        // Soft beige/paper color for Gangle's ribbon body
    }

    @Override
    public void think(ArrayList<Entity> allEntities) {
        super.think(allEntities);
        // Add Gangle-specific logic later if needed
    }
}
