package com.circus.world;
import com.circus.main.ShaderHandler;
import java.awt.*;

public class CircusGrounds {
    public void render(Graphics2D g2, int width, int height, double camX, double camZ, double yaw) {
        int cx = width / 2, cy = height / 2;

        // 1. ATMOSPHERIC SKYBOX
        g2.setPaint(new GradientPaint(0, 0, new Color(15, 0, 25), 0, cy, new Color(40, 0, 60)));
        g2.fillRect(0, 0, width, height);

        // 2. RENDER THE GROUND & CIRCUS STRUCTURES
        // We loop through a grid to place "Bleachers" and the "Ring"
        for (int z = 0; z <= 5000; z += 250) {
            for (int x = -2500; x <= 2500; x += 250) {
                // Perspective Transform
                double dx = x - camX, dz = z - camZ;
                double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
                double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);

                if (rz < 50) continue;

                int px = (int)((rx / rz) * 800) + cx;
                int py = (int)(400 / rz * 800) + cy;
                int size = (int)(15000 / rz);

                // DRAW THE CENTRAL RING (Fixed at 0, 1000)
                double distToRing = Math.sqrt(Math.pow(x, 2) + Math.pow(z - 1000, 2));
                if (distToRing < 400) {
                    g2.setColor(ShaderHandler.applyShading(new Color(100, 0, 0), rz, 1.2));
                    g2.fillOval(px - size/2, py - size/4, size, size/2);
                    continue;
                }

                // DRAW THE BLEACHERS (Outer Edges)
                if (Math.abs(x) > 800 || z > 2000) {
                    int bH = (int)((Math.abs(x) * 0.1) * (800 / rz)); // Height increases with distance
                    g2.setColor(ShaderHandler.applyShading(new Color(60, 40, 30), rz, 0.5));
                    g2.fillRect(px - size/2, py - bH, size, bH);
                    g2.setColor(Color.BLACK);
                    g2.drawRect(px - size/2, py - bH, size, bH);
                }
            }
        }

        // 3. THE TENT POLES (Giant Vertical Rectangles)
        renderPole(g2, -600, 1000, camX, camZ, yaw, cx, cy);
        renderPole(g2, 600, 1000, camX, camZ, yaw, cx, cy);
    }

    private void renderPole(Graphics2D g2, int x, int z, double cx, double cz, double yaw, int midX, int midY) {
        double dx = x - cx, dz = z - cz;
        double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
        double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);
        if (rz < 50) return;

        int px = (int)((rx / rz) * 800) + midX;
        int py = midY;
        int pW = (int)(5000 / rz);
        int pH = (int)(40000 / rz);

        g2.setColor(ShaderHandler.applyShading(new Color(180, 180, 180), rz, 0.8));
        g2.fillRect(px - pW/2, py - pH, pW, pH);
    }
}