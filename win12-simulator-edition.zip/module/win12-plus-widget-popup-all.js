
(function(){'use strict';
function Q(q){return window.jQuery?window.jQuery(q):document.querySelectorAll(q)}
function ready(cb){var n=0,t=setInterval(function(){n++;if(window.Win12Plus&&typeof widgets!=='undefined'&&window.jQuery&&window.shownotice){clearInterval(t);cb()}if(n>180)clearInterval(t)},100)}
ready(function(){
var ALL_WIDGETS=[
 ['zerocode','0 Code Widget'],
 ['quicknotes','Quick Notes'],
 ['vfsstats','VFS Stats'],
 ['worldclock','World Clock'],
 ['rssheadlines','News Sources'],
 ['todoPlus','To Do'],
 ['launcherPlus','App Launcher'],
 ['fileSearchPlus','VFS Search'],
 ['clipboardPlus','Clipboard'],
 ['calendarPlus','Calendar'],
 ['registryWidget','Registry Handlers'],
 ['recentFilesWidget','Recent VFS Files'],
 ['storageWidget','VFS Storage'],
 ['commandWidget','Command Box'],
 ['newsMiniWidget','Mini News']
];
// Intentionally not listed: customWidget. It stays hidden and is only created from 0 Code Widget > Create.
function addWidgetOptions(){
 var list=Q('.notice list.new');
 if(!list.length)return;
 list.find('a.plus-widget-option-all').remove();
 var existing={};
 list.find('a').each(function(){existing[Q(this).text().trim()]=true});
 ALL_WIDGETS.forEach(function(w){
   if(!existing[w[1]]) list.append('<a class="a plus-widget-option-all" onclick="closenotice();widgets.widgets.add(\''+w[0]+'\')">'+w[1]+'</a>');
 });
 var seen={};
 list.find('a').each(function(){var t=Q(this).text().trim();if(seen[t])Q(this).remove();else seen[t]=1});
}
window.Win12PlusWidgetPopupAll={widgets:ALL_WIDGETS,install:addWidgetOptions};
var old=window.shownotice;
window.shownotice=function(name){var r=old.apply(window,arguments);if(name==='widgets'){setTimeout(addWidgetOptions,60);setTimeout(addWidgetOptions,180);setTimeout(addWidgetOptions,360)}return r};
// If the widget popup is already open, update it immediately.
setTimeout(addWidgetOptions,100);
console.log('Win12 Plus all-widget popup layer loaded');
});
})();
