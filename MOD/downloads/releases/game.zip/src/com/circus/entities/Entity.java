package com.circus.entities;

import com.circus.world.CircusGrounds;
import java.awt.Color;
import java.util.Random;
import java.util.ArrayList;

public class Entity {
    public String name;
    public double x, z, y = 100;
    public Color skinColor;

    // AI STATE
    private double targetX, targetZ;
    private long lastStateChange = 0;
    private String currentState = "WANDER";
    private Entity chaseTarget = null;
    private Random rand = new Random();

    public Entity(String name, Color color, double x, double z) {
        this.name = name;
        this.skinColor = color;
        this.x = x;
        this.z = z;
        setNewWanderTarget();
    }

    /** Assigns a new random wander location */
    private void setNewWanderTarget() {
        targetX = rand.nextInt(2000) - 1000;
        targetZ = rand.nextInt(2000) + 500;
    }

    /** Main AI brain — inherited by Ragatha, Zooble, Gangle, etc. */
    public void think(ArrayList<Entity> allEntities) {
        long now = System.currentTimeMillis();

        // --- STATE SWITCHER (every 10 seconds) ---
        if (now - lastStateChange > 10000) {
            lastStateChange = now;

            if (rand.nextBoolean()) {
                currentState = "CHASE";

                // Pick a random entity to chase (not self)
                if (allEntities.size() > 1) {
                    do {
                        chaseTarget = allEntities.get(rand.nextInt(allEntities.size()));
                    } while (chaseTarget == this);
                }

            } else {
                currentState = "WANDER";
                setNewWanderTarget();
            }
        }

        // --- MOVEMENT LOGIC ---
        double speed = currentState.equals("CHASE") ? 8.0 : 3.0;

        double tx = (currentState.equals("CHASE") && chaseTarget != null) ? chaseTarget.x : targetX;
        double tz = (currentState.equals("CHASE") && chaseTarget != null) ? chaseTarget.z : targetZ;

        double dx = tx - x;
        double dz = tz - z;
        double dist = Math.sqrt(dx*dx + dz*dz);

        if (dist > 5) {
            x += (dx / dist) * speed;
            z += (dz / dist) * speed;
        } else if (currentState.equals("WANDER")) {
            setNewWanderTarget();
        }

        // --- INTERACTION: Center Ring Bounce ---
        double distToRing = Math.sqrt(Math.pow(x, 2) + Math.pow(z - 1000, 2));

        if (distToRing < 400) {
            y = 100 - (Math.abs(Math.sin(now * 0.01)) * 50);
        } else {
            y = 100;
        }
    }
}
