import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class main {
    public static void main(String[] args) {
        JFrame f = new JFrame("Plugin Status");
        f.setSize(400, 200);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel label = new JLabel("PLUGIN WORKS", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 32));
        label.setForeground(Color.GREEN);

        f.add(label);
        f.setVisible(true);
    }
}
