# Mini OS Runtime
import os
import tkinter as tk

def open_window(title):
    root = tk.Tk()
    root.title(title)
    root.geometry('300x200')
    label = tk.Label(root, text=title)
    label.pack()
    root.after(100, root.destroy)
    root.mainloop()

def write(text):
    print(text)

def writefile(name, content):
    with open(name, 'w', encoding='utf-8') as f:
        f.write(content)

def readfile(name):
    try:
        with open(name, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return str(e)

open_window('Main Window')
write('Booting system...')
x = 1
if x == 1:
    write('Condition met')
else:
    write('Fail')
i = 0
while i < 3:
    write(i)
    i = i + 1
writefile('test.txt', 'Hello World')
write(readfile('test.txt'))
write('System ready')
