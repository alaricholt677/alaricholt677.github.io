package com.circus.menus;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public abstract class CircusMenu {
    // This must be public so subclasses can see it!
    public ArrayList<UIElement> elements = new ArrayList<>();

    public abstract void draw(Graphics2D g2);

    public void click(int mx, int my) {
        for (UIElement el : elements) el.onClick(mx, my);
    }

    public void key(KeyEvent e) {
        for (UIElement el : elements) el.onKey(e);
    }
}