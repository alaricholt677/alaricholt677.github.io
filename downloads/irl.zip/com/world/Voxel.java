package com.world;

public final class Voxel {

    public static final byte AIR   = 0;
    public static final byte GRASS = 1;
    public static final byte DIRT  = 2;
    public static final byte STONE = 3;
    public static final byte TORCH = 4;

    public static final int LIGHT_MAX = 15;

    public final byte type;

    public Voxel(byte type) { this.type = type; }

    public boolean isSolid() { return type != AIR; }

    public static int emission(byte type) {
        return switch (type) {
            case TORCH -> 14;
            default -> 0;
        };
    }
}
