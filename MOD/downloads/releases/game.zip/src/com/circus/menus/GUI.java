package com.circus.menus;

import java.awt.*;
import java.awt.event.KeyEvent;

// REMOVED 'public' TO ALLOW COEXISTENCE IN GUI.JAVA
abstract class UIElement {
    public int x, y, width, height;
    public UIElement(int x, int y, int w, int h) { this.x=x; this.y=y; this.width=w; this.height=h; }
    public abstract void draw(Graphics2D g2);
    public void onClick(int mx, int my) {}
    public void onKey(KeyEvent e) {}
}

class Button extends UIElement {
    String text;
    Runnable action;
    public Button(int x, int y, int w, int h, String text, Runnable action) {
        super(x, y, w, h); this.text = text; this.action = action;
    }
    @Override
    public void draw(Graphics2D g2) {
        g2.setColor(new Color(150, 0, 0, 230)); // Circus Red
        g2.fillRect(x, y, width, height);
        g2.setColor(Color.WHITE);
        g2.drawRect(x, y, width, height);
        g2.drawString(text, x + 20, y + 25);
    }
    @Override
    public void onClick(int mx, int my) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + height) action.run();
    }
}

class TextBox extends UIElement {
    public String text = "";
    public TextBox(int x, int y, int w, int h) { super(x, y, w, h); }
    @Override
    public void draw(Graphics2D g2) {
        g2.setColor(Color.BLACK);
        g2.fillRect(x, y, width, height);
        g2.setColor(Color.YELLOW);
        g2.drawRect(x, y, width, height);
        g2.drawString(text + "|", x + 10, y + 25);
    }
    @Override
    public void onKey(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE && text.length() > 0) text = text.substring(0, text.length() - 1);
        else if (e.getKeyChar() >= 32 && e.getKeyChar() <= 126) text += e.getKeyChar();
    }
}