# AI Copilot 介绍
本 AI 由云智 API 提供支持，文档来自 github@tangyuan0821

原文档由 github@NB-Group 提供，可查看其在互联网档案馆的[存档](https://web.archive.org/web/20251115175835/https://github.com/win12-online/win12/blob/main/scripts/AI%20Copilot%20service/README.md)
## 介绍
AI Copilot 是一个基于 Deepseek v4 pro 的文本生成工具，可以生成文本。本 AI 由云智 API（[yunzhiapi.cn](https://www.yunzhiapi.cn)）提供支持，其接受来自前端页面的请求，并返回生成文本。

## 问题反馈
如在使用过程中出现问题可以通过[issues](https://github.com/win12-online/win12/issues)提交反馈
