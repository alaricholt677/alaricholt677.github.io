package com.entities;

import java.awt.Color;

public class TerrainChunk extends BaseEntity {

    public TerrainChunk() {}

    @Override
    public void tick() {
        // Terrain does not move or use gravity
    }

    public void buildFromHeightmap(double[][] h, double cellSize, Color low, Color high) {
        mesh.vertices.clear();
        mesh.triangles.clear();

        int size = h.length; // expected (N+1)x(N+1)
        int quads = size - 1;

        // vertices
        for (int z = 0; z < size; z++) {
            for (int x = 0; x < size; x++) {
                double y = h[z][x];
                mesh.vertices.add(new Vertex(x * cellSize, y, z * cellSize));
            }
        }

        // triangles
        for (int z = 0; z < quads; z++) {
            for (int x = 0; x < quads; x++) {
                int i0 = idx(x, z, size);
                int i1 = idx(x + 1, z, size);
                int i2 = idx(x + 1, z + 1, size);
                int i3 = idx(x, z + 1, size);

                double avgH = (h[z][x] + h[z][x+1] + h[z+1][x] + h[z+1][x+1]) * 0.25;
                double t = clamp01((avgH + 2.0) / 6.0);
                Color c = lerp(low, high, t);

                mesh.triangles.add(new Triangle(i0, i1, i2, c));
                mesh.triangles.add(new Triangle(i0, i2, i3, c));
            }
        }
    }

    private int idx(int x, int z, int size) {
        return z * size + x;
    }

    private double clamp01(double v) { return (v < 0) ? 0 : (v > 1) ? 1 : v; }

    private Color lerp(Color a, Color b, double t) {
        int r = (int)Math.round(a.getRed() + (b.getRed() - a.getRed()) * t);
        int g = (int)Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t);
        int bl = (int)Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t);
        return new Color(clamp255(r), clamp255(g), clamp255(bl));
    }

    private int clamp255(int v) { return (v < 0) ? 0 : (v > 255) ? 255 : v; }
}
