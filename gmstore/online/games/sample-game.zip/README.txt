﻿GM Store sample game. Run SampleGame.jar. Use WASD or arrow keys.
