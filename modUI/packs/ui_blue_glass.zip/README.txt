UI Theme Blue Glass
===================

Pack ID: ui_blue_glass
Version: 1.0.0

Description:
Adds a blue glass style UI theme concept for menus, buttons, panels, mod cards, chat overlays, and futuristic interface testing.

This is a starter/template expansion zip for the IRL Simulator Mod Store.
Your current store UI downloads packs into the expansion_packs folder.

Suggested future install flow:
1. Download this zip.
2. Verify pack_manifest.json.
3. Read data/*.json.
4. Import only safe data into your engine.
5. Never run downloaded Java code automatically.
