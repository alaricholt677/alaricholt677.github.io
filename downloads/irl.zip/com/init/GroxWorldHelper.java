package com.init;

import java.io.*;
import java.nio.file.*;
import main.Main;

public class GroxWorldHelper {
    public static void forceModifyWorld() {
        if (!"Grox".equalsIgnoreCase(Main.USER_NAME)) return;

        try {
            File configDir = new File("configs");
            if (!configDir.exists()) return;

            for (File level : configDir.listFiles()) {
                if (level.isDirectory()) {
                    // Force name.txt
                    Files.writeString(new File(level, "name.txt").toPath(), "im sexy uhh");

                    // Force options.txt to the most unoptimized settings possible
                    String options = "#Level options\n" +
                                     "chunkMeshing=true\n" + 
                                     "chunkStreaming=false\n" + 
                                     "occlusionCulling=false\n" + 
                                     "renderDistanceChunks=1000";
                    Files.writeString(new File(level, "options.txt").toPath(), options);
                    
                    // Rename the folder
                    level.renameTo(new File(configDir, "EMO_WORLD_" + level.getName()));
                }
            }
        } catch (Exception e) {}
    }
}