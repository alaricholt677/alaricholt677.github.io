import javax.swing.*;
import java.awt.*;
import java.io.*;

public class SaveEditor extends JFrame {

    private JTextField xField = new JTextField("1000000.0");
    private JTextField yField = new JTextField("1000000.0");
    private JTextField zField = new JTextField("1000000.0");

    // 9 hotbar slots
    private byte[] hotbar = new byte[9];
    private JLabel[] hotbarLabels = new JLabel[9];
    private int hotbarIndex = 0;

    public SaveEditor() {
        setTitle("Save File Editor + Block Picker");
        setLayout(new BorderLayout(10, 10));

        // ============================
        // TOP: POSITION INPUTS
        // ============================
        JPanel posPanel = new JPanel(new GridLayout(3, 2, 6, 6));
        posPanel.setBorder(BorderFactory.createTitledBorder("Player Position"));

        posPanel.add(new JLabel("X Coordinate:")); posPanel.add(xField);
        posPanel.add(new JLabel("Y Coordinate:")); posPanel.add(yField);
        posPanel.add(new JLabel("Z Coordinate:")); posPanel.add(zField);

        add(posPanel, BorderLayout.NORTH);

        // ============================
        // CENTER: BLOCK PICKER
        // ============================
        JPanel pickerPanel = new JPanel(new GridLayout(2, 1, 6, 6));
        pickerPanel.setBorder(BorderFactory.createTitledBorder("Block Picker"));

        // --- BASIC BLOCKS (1–9)
        JPanel basicPanel = new JPanel(new GridLayout(3, 3, 4, 4));
        basicPanel.setBorder(BorderFactory.createTitledBorder("Basic Blocks (1–9)"));

        addBlockButton(basicPanel, "1 Grass", 1);
        addBlockButton(basicPanel, "2 Dirt", 2);
        addBlockButton(basicPanel, "3 Stone", 3);
        addBlockButton(basicPanel, "4 Torch", 4);
        addBlockButton(basicPanel, "5 Hellstone", 5);
        addBlockButton(basicPanel, "6 Bloodrock", 6);
        addBlockButton(basicPanel, "7 Ash", 7);
        addBlockButton(basicPanel, "8 Fire", 8);
        addBlockButton(basicPanel, "9 Hell Portal", 9);

        // --- CRAFTED BLOCKS (20–24)
        JPanel craftedPanel = new JPanel(new GridLayout(1, 5, 4, 4));
        craftedPanel.setBorder(BorderFactory.createTitledBorder("Crafted Blocks (20–24)"));

        addBlockButton(craftedPanel, "20 Crafting Table", 20);
        addBlockButton(craftedPanel, "21 Crafted_1", 21);
        addBlockButton(craftedPanel, "22 Crafted_2", 22);
        addBlockButton(craftedPanel, "23 Crafted_3", 23);
        addBlockButton(craftedPanel, "24 Crafted_4", 24);

        pickerPanel.add(basicPanel);
        pickerPanel.add(craftedPanel);

        add(pickerPanel, BorderLayout.CENTER);

        // ============================
        // RIGHT: HOTBAR PREVIEW
        // ============================
        JPanel hotbarPanel = new JPanel(new GridLayout(9, 1, 4, 4));
        hotbarPanel.setBorder(BorderFactory.createTitledBorder("Hotbar (9 slots)"));

        for (int i = 0; i < 9; i++) {
            hotbarLabels[i] = new JLabel("Slot " + (i + 1) + ": EMPTY");
            hotbarPanel.add(hotbarLabels[i]);
        }

        add(hotbarPanel, BorderLayout.EAST);

        // ============================
        // BOTTOM: SAVE BUTTON
        // ============================
        JButton saveButton = new JButton("Save & Overwrite playerpos.dat");
        saveButton.addActionListener(e -> saveFile());
        add(saveButton, BorderLayout.SOUTH);

        // ============================
        // WINDOW SETTINGS
        // ============================
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // ============================================================
    // ADD BLOCK BUTTON
    // ============================================================
    private void addBlockButton(JPanel panel, String name, int id) {
        JButton btn = new JButton(name);
        btn.addActionListener(e -> addToHotbar((byte) id));
        panel.add(btn);
    }

    // ============================================================
    // ADD BLOCK TO HOTBAR
    // ============================================================
    private void addToHotbar(byte id) {
        if (hotbarIndex >= 9) {
            JOptionPane.showMessageDialog(this, "Hotbar is full!");
            return;
        }

        hotbar[hotbarIndex] = id;
        hotbarLabels[hotbarIndex].setText("Slot " + (hotbarIndex + 1) + ": " + id);
        hotbarIndex++;
    }

    // ============================================================
    // SAVE FILE
    // ============================================================
    private void saveFile() {
        try (DataOutputStream out = new DataOutputStream(
                new BufferedOutputStream(new FileOutputStream("playerpos.dat")))) {

            // Position
            out.writeDouble(Double.parseDouble(xField.getText()));
            out.writeDouble(Double.parseDouble(yField.getText()));
            out.writeDouble(Double.parseDouble(zField.getText()));

            // Selected hotbar slot
            out.writeInt(0);

            // Write 9 hotbar bytes
            for (int i = 0; i < 9; i++) {
                out.writeByte(hotbar[i]);
            }

            JOptionPane.showMessageDialog(this, "Success: playerpos.dat saved!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new SaveEditor();
    }
}
