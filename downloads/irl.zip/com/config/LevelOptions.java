package com.config;

import java.io.*;
import java.util.Properties;

public final class LevelOptions {
    public boolean occlusionCulling = true;
    public boolean chunkStreaming = true;
    public boolean chunkMeshing = false; // OFF by default (your request)
    public int renderDistanceChunks = 6;

    public static LevelOptions load(File f) {
        LevelOptions o = new LevelOptions();
        if (!f.exists()) return o;

        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(f)) {
            p.load(in);
            o.occlusionCulling = Boolean.parseBoolean(p.getProperty("occlusionCulling", "true"));
            o.chunkStreaming = Boolean.parseBoolean(p.getProperty("chunkStreaming", "true"));
            o.chunkMeshing = Boolean.parseBoolean(p.getProperty("chunkMeshing", "false"));
            o.renderDistanceChunks = Integer.parseInt(p.getProperty("renderDistanceChunks", "6"));
        } catch (Exception ignored) {}
        return o;
    }

    public void save(File f) {
        Properties p = new Properties();
        p.setProperty("occlusionCulling", String.valueOf(occlusionCulling));
        p.setProperty("chunkStreaming", String.valueOf(chunkStreaming));
        p.setProperty("chunkMeshing", String.valueOf(chunkMeshing));
        p.setProperty("renderDistanceChunks", String.valueOf(renderDistanceChunks));

        try (FileOutputStream out = new FileOutputStream(f)) {
            p.store(out, "Level options");
        } catch (Exception ignored) {}
    }
}
