package com.world;

import com.config.LevelOptions;
import com.entities.BaseEntity;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class World {

    private final int radius;
    private final Chunk[][] chunks;
    private LevelOptions options = new LevelOptions();

    public World() { this(4); }

    public World(int radius) {
        this.radius = radius;
        int size = radius * 2 + 1;
        chunks = new Chunk[size][size];

        for (int z = 0; z < size; z++)
            for (int x = 0; x < size; x++) {
                int cx = x - radius;
                int cz = z - radius;
                Chunk c = new Chunk(cx, cz);
                generateChunk(c);
                c.setWorldPosition();
                chunks[x][z] = c;
            }

        rebuildAllLighting();
        rebuildAllMeshes();
    }

    public void applyOptions(LevelOptions o) {
        if (o == null) return;
        this.options = o;
        rebuildAllMeshes();
    }

    public int getRadius() { return radius; }
    public Chunk[][] getChunkGrid() { return chunks; }

    public void loadFromLevelDir(File levelDir) {
        try {
            File blocks = new File(new File(levelDir, "blockdata"), "blocks.dat");
            BlockStorage.load(blocks, this);
        } catch (Exception ignored) {}

        rebuildAllLighting();
        rebuildAllMeshes();
    }

    public void saveToLevelDir(File levelDir) {
        try {
            File blocks = new File(new File(levelDir, "blockdata"), "blocks.dat");
            BlockStorage.save(blocks, this);
        } catch (Exception ignored) {}
    }

    public List<BaseEntity> visibleMeshes(double camX, double camZ, double yaw) {
        List<BaseEntity> out = new ArrayList<>();

        int rd = Math.max(1, options.renderDistanceChunks);
        double maxDist = rd * Chunk.SIZE;

        for (var row : chunks) {
            for (var c : row) {
                double wx = c.cx * Chunk.SIZE + Chunk.SIZE * 0.5;
                double wz = c.cz * Chunk.SIZE + Chunk.SIZE * 0.5;

                double dx = wx - camX;
                double dz = wz - camZ;

                if (options.chunkStreaming && dx * dx + dz * dz > maxDist * maxDist) {
                    if (c.loaded) c.unloadMesh();
                    continue;
                }

                if (!c.loaded) c.rebuildMesh(this);
                out.add(c.meshEntity);
            }
        }

        return out;
    }

    // REQUIRED by MovementController
    public double surfaceHeight(double x, double z) {
        int gx = (int)Math.floor(x / Chunk.SIZE) + radius;
        int gz = (int)Math.floor(z / Chunk.SIZE) + radius;
        if (gx < 0 || gz < 0 || gx >= chunks.length || gz >= chunks.length) return 0;

        Chunk c = chunks[gx][gz];

        int lx = (int)Math.floor(x - c.cx * Chunk.SIZE);
        int lz = (int)Math.floor(z - c.cz * Chunk.SIZE);

        lx = clamp(lx, 0, Chunk.SIZE - 1);
        lz = clamp(lz, 0, Chunk.SIZE - 1);

        for (int y = Chunk.SIZE - 1; y >= 0; y--) {
            if (c.voxels[lx][y][lz].isSolid()) return y + 1; // stand on top
        }
        return 0;
    }

    public boolean isAir(int wx, int wy, int wz) {
        return getBlock(wx, wy, wz) == Voxel.AIR;
    }

    public byte getBlock(int wx, int wy, int wz) {
        Chunk c = chunkAtWorld(wx, wz);
        if (c == null) return Voxel.AIR;

        int lx = mod(wx, Chunk.SIZE);
        int lz = mod(wz, Chunk.SIZE);
        if (wy < 0 || wy >= Chunk.SIZE) return Voxel.AIR;

        return c.voxels[lx][wy][lz].type;
    }

    public int getLight(int wx, int wy, int wz) {
        Chunk c = chunkAtWorld(wx, wz);
        if (c == null) return 0;

        int lx = mod(wx, Chunk.SIZE);
        int lz = mod(wz, Chunk.SIZE);
        if (wy < 0 || wy >= Chunk.SIZE) return 0;

        return c.light[lx][wy][lz] & 0xFF;
    }

    public boolean setBlock(int wx, int wy, int wz, byte type) {
        Chunk c = chunkAtWorld(wx, wz);
        if (c == null) return false;

        int lx = mod(wx, Chunk.SIZE);
        int lz = mod(wz, Chunk.SIZE);
        if (wy < 0 || wy >= Chunk.SIZE) return false;

        c.voxels[lx][wy][lz] = new Voxel(type);
        c.markDirty();

        rebuildLightingNeighborhood(wx, wz);
        rebuildMeshNeighborhood(wx, wz);

        return true;
    }

    // REQUIRED by Chunk lighting
    public void floodLightFrom(int wx, int wy, int wz, int start) {
        if (start <= 0) return;

        final class Node {
            final int x, y, z, l;
            Node(int x, int y, int z, int l) { this.x = x; this.y = y; this.z = z; this.l = l; }
        }

        ArrayDeque<Node> q = new ArrayDeque<>();
        q.add(new Node(wx, wy, wz, start));

        while (!q.isEmpty()) {
            Node n = q.removeFirst();
            if (n.l <= 0) continue;
            if (n.y < 0 || n.y >= Chunk.SIZE) continue;

            // Don’t propagate through solid blocks (except the emitter itself, which is handled by seeding)
            byte bt = getBlock(n.x, n.y, n.z);
            if (bt != Voxel.AIR && Voxel.emission(bt) == 0) continue;

            Chunk c = chunkAtWorld(n.x, n.z);
            if (c == null) continue;

            int lx = mod(n.x, Chunk.SIZE);
            int lz = mod(n.z, Chunk.SIZE);

            int cur = c.light[lx][n.y][lz] & 0xFF;
            if (n.l <= cur) continue;

            c.light[lx][n.y][lz] = (byte)n.l;

            int nl = n.l - 1;
            q.add(new Node(n.x + 1, n.y, n.z, nl));
            q.add(new Node(n.x - 1, n.y, n.z, nl));
            q.add(new Node(n.x, n.y + 1, n.z, nl));
            q.add(new Node(n.x, n.y - 1, n.z, nl));
            q.add(new Node(n.x, n.y, n.z + 1, nl));
            q.add(new Node(n.x, n.y, n.z - 1, nl));
        }
    }

    public void rebuildAllLighting() {
        for (var row : chunks)
            for (var c : row)
                c.rebuildLighting(this);
    }

    private void rebuildAllMeshes() {
        for (var row : chunks)
            for (var c : row)
                c.rebuildMesh(this);
    }

    private void rebuildLightingNeighborhood(int wx, int wz) {
        Chunk c = chunkAtWorld(wx, wz);
        if (c == null) return;

        for (int dz = -1; dz <= 1; dz++)
            for (int dx = -1; dx <= 1; dx++) {
                Chunk n = chunkAtChunk(c.cx + dx, c.cz + dz);
                if (n != null) n.rebuildLighting(this);
            }
    }

    private void rebuildMeshNeighborhood(int wx, int wz) {
        Chunk c = chunkAtWorld(wx, wz);
        if (c == null) return;

        c.rebuildMesh(this);
        Chunk n;
        n = chunkAtChunk(c.cx - 1, c.cz); if (n != null) n.rebuildMesh(this);
        n = chunkAtChunk(c.cx + 1, c.cz); if (n != null) n.rebuildMesh(this);
        n = chunkAtChunk(c.cx, c.cz - 1); if (n != null) n.rebuildMesh(this);
        n = chunkAtChunk(c.cx, c.cz + 1); if (n != null) n.rebuildMesh(this);
    }

    private Chunk chunkAtWorld(int wx, int wz) {
        int cx = (int)Math.floor(wx / (double)Chunk.SIZE);
        int cz = (int)Math.floor(wz / (double)Chunk.SIZE);
        return chunkAtChunk(cx, cz);
    }

    private Chunk chunkAtChunk(int cx, int cz) {
        int gx = cx + radius;
        int gz = cz + radius;
        if (gx < 0 || gz < 0 || gx >= chunks.length || gz >= chunks.length) return null;
        return chunks[gx][gz];
    }

    private void generateChunk(Chunk c) {
        for (int x = 0; x < Chunk.SIZE; x++)
            for (int z = 0; z < Chunk.SIZE; z++) {
                int wx = c.cx * Chunk.SIZE + x;
                int wz = c.cz * Chunk.SIZE + z;

                int height = 6
                        + (int)(Math.sin(wx * 0.15) * 2)
                        + (int)(Math.cos(wz * 0.15) * 2);

                height = clamp(height, 1, Chunk.SIZE - 1);

                for (int y = 0; y < height; y++) {
                    c.voxels[x][y][z] = new Voxel(
                            y == height - 1 ? Voxel.GRASS :
                            y > height - 4 ? Voxel.DIRT :
                            Voxel.STONE
                    );
                }
            }
    }

    private int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    private int mod(int a, int m) { int r = a % m; return r < 0 ? r + m : r; }
}
