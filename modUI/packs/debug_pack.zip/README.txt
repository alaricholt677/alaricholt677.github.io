Debug Pack
==========

Pack ID: debug_pack
Version: 1.0.0

Description:
Adds debug notes, example data files, test blocks, test entities, and simple files for checking whether the mod store downloader works.

This is a starter/template expansion zip for the IRL Simulator Mod Store.
Your current store UI downloads packs into the expansion_packs folder.

Suggested future install flow:
1. Download this zip.
2. Verify pack_manifest.json.
3. Read data/*.json.
4. Import only safe data into your engine.
5. Never run downloaded Java code automatically.
