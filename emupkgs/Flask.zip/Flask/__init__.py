# Flask emulator package (FINAL FIXED VERSION)
# Supports:
#   import Flask;
#   route "/path":
#   OS syntax inside routes
#   Preserves indentation
#   Auto Flask runtime injection

import re

# Detect emulator import line: import Flask;
PLUGIN_IMPORT_RE = re.compile(
    r"^\s*import\s+Flask\s*;\s*$",
    re.IGNORECASE
)

# Detect route syntax: route "/path":
ROUTE_RE = re.compile(
    r'^route\s+"(.+)"\s*:$',
    re.IGNORECASE
)


def convert(text: str) -> str:
    lines = text.splitlines()
    out = []
    body_lines = []

    # -----------------------------------------
    # Strip emulator import + preserve structure
    # -----------------------------------------
    for raw in lines:
        line = raw.rstrip("\n")

        # Remove emulator import
        if PLUGIN_IMPORT_RE.match(line):
            continue

        # Preserve blank lines
        if line.strip() == "":
            body_lines.append("")
            continue

        body_lines.append(line)

    body = "\n".join(body_lines).strip("\n")

    # -----------------------------------------
    # Inject Flask runtime if missing
    # -----------------------------------------
    has_flask_import = (
        "from flask import" in body
        or "import flask" in body
    )

    has_app = "app = Flask(" in body

    if not has_flask_import:
        out.append("from flask import Flask, request, jsonify, render_template_string, send_from_directory")

    if not has_app:
        out.append("")
        out.append("app = Flask(__name__)")

    out.append("")

    # -----------------------------------------
    # Parse body line-by-line for route syntax
    # -----------------------------------------
    for raw in body.splitlines():
        stripped = raw.lstrip()
        indent = raw[:len(raw) - len(stripped)]

        # Route syntax: route "/path":
        m = ROUTE_RE.match(stripped)
        if m:
            route_path = m.group(1)

            # Safe function name
            safe_name = "route_" + route_path.strip("/").replace("/", "_").replace("-", "_")
            if safe_name == "route_":
                safe_name = "route_root"

            out.append(f"{indent}@app.route({repr(route_path)})")
            out.append(f"{indent}def {safe_name}():")
            continue

        # Otherwise preserve raw Python or OS-transformed code
        out.append(raw)

    # -----------------------------------------
    # Auto-run Flask server (SAFE main guard)
    # -----------------------------------------
    out.append("")
    out.append("if __name__ == '__main__':")
    out.append("    app.run(host='0.0.0.0', port=5000, debug=False)")

    return "\n".join(out)


def combine(text: str) -> str:
    return text.strip() + "\n"
