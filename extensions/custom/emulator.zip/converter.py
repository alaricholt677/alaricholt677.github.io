import sys
import re
import importlib.util
from pathlib import Path

WORKDIR = Path(__file__).resolve().parent
PATH_TXT = WORKDIR / "path.txt"
APP = WORKDIR / "app.py"
ERR = WORKDIR / "errors.log"

PKG_ROOT = Path.home() / "AppData" / "Local" / "EmulatorPackages"


# ============================================================
# Read .emulator file path
# ============================================================

def read_emulator_path() -> Path:
    if not PATH_TXT.exists():
        raise FileNotFoundError("path.txt not found")
    return Path(PATH_TXT.read_text(encoding="utf-8").strip())


# ============================================================
# Load plugin from AppData
# ============================================================

def load_plugin(pkg_name: str):
    pkg_path = PKG_ROOT / pkg_name / pkg_name / "__init__.py"

    if not pkg_path.exists():
        raise FileNotFoundError(f"Plugin not found: {pkg_path}")

    spec = importlib.util.spec_from_file_location(pkg_name, pkg_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ============================================================
# Extract imports from .emulator file
# ============================================================

IMPORT_RE = re.compile(r"import\s+([A-Za-z0-9_]+);?")

def extract_imports(text: str):
    return IMPORT_RE.findall(text)


def strip_imports(text: str):
    return IMPORT_RE.sub("", text)


# ============================================================
# Main multi-stage conversion pipeline
# ============================================================

def run_pipeline(src_path: Path, text: str):
    # 1. Find imports
    imports = extract_imports(text)

    # 2. Strip import lines from source
    clean_text = strip_imports(text)

    # 3. Load plugins
    plugins = []
    for pkg in imports:
        try:
            mod = load_plugin(pkg)
            if not hasattr(mod, "convert"):
                raise RuntimeError(f"Plugin {pkg} missing convert()")
            plugins.append(mod)
        except Exception as e:
            raise RuntimeError(f"Failed to load plugin {pkg}: {e}")

    # 4. Run converters in order
    intermediate = clean_text
    for plugin in plugins:
        try:
            intermediate = plugin.convert(intermediate)
        except Exception as e:
            raise RuntimeError(f"Plugin {plugin.__name__} failed: {e}")

    # 5. Combine stage (optional)
    for plugin in plugins:
        if hasattr(plugin, "combine"):
            try:
                intermediate = plugin.combine(intermediate)
            except Exception as e:
                raise RuntimeError(f"Combiner in {plugin.__name__} failed: {e}")

    return intermediate


# ============================================================
# Write final app.py
# ============================================================

def write_app(py_code: str):
    APP.write_text(py_code, encoding="utf-8")


# ============================================================
# Main
# ============================================================

def main():
    try:
        src_path = read_emulator_path()
        text = src_path.read_text(encoding="utf-8")

        final_py = run_pipeline(src_path, text)
        write_app(final_py)

        print("Conversion OK. app.py ready.")

    except Exception as e:
        ERR.write_text(f"error: {e}", encoding="utf-8")
        print("Errors found. See errors.log")
        sys.exit(1)


if __name__ == "__main__":
    main()
