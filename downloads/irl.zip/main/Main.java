package main;

import com.init.GameLoader;
import com.init.GroxWorldHelper; // Make sure your new helper is imported

public class Main {

    public static String USER_NAME;
    public static String SKIN_DIR;
    public static String PATH_TO_CLASSES;

    /**
     * The Entry Point. 
     * We have injected the Grox check specifically between the argument 
     * parsing and the boot sequence.
     */
    public static void main(String[] args) {
        // 1. Parse arguments to find out who is playing
        ParsedArgs p = parseArgsStrict(args);

        // 2. Set the global variables
        PATH_TO_CLASSES = p.pathToClasses;
        USER_NAME = p.name; // This will be "Grox"
        SKIN_DIR = p.skinDir;

        // --- STRICT INJECTION POINT START ---
        // We run the world modifier NOW. 
        // If we wait until after runBootSequence, the original world 
        // options will already be loaded into the game's memory.
        com.init.GroxWorldHelper.forceModifyWorld(); 
        // --- STRICT INJECTION POINT END ---

        // 3. Load the game (now using the renamed folders and 1000 render distance)
        GameLoader.runBootSequence(PATH_TO_CLASSES, USER_NAME, SKIN_DIR);

        // 4. Start the engine
        new Engine().start();
    }

    private static ParsedArgs parseArgsStrict(String[] args) {
        if (args == null || args.length != 6) {
            throw new IllegalArgumentException("Usage: --PathToClasses <path> --Name <name> --skinDir <dir>");
        }

        String pathToClasses = null, name = null, skinDir = null;

        for (int i = 0; i < 6; i += 2) {
            String k = args[i];
            String v = args[i + 1];

            if (v == null || v.trim().isEmpty() || v.startsWith("--")) {
                throw new IllegalArgumentException("Invalid value for " + k);
            }

            if ("--PathToClasses".equals(k)) pathToClasses = v;
            else if ("--Name".equals(k)) name = v;
            else if ("--skinDir".equals(k)) skinDir = v;
            else throw new IllegalArgumentException("Unknown argument: " + k);
        }

        if (pathToClasses == null || name == null || skinDir == null) {
            throw new IllegalArgumentException("Missing required args. Usage: --PathToClasses <path> --Name <name> --skinDir <dir>");
        }

        return new ParsedArgs(pathToClasses, name, skinDir);
    }

    private static final class ParsedArgs {
        final String pathToClasses, name, skinDir;
        ParsedArgs(String pathToClasses, String name, String skinDir) {
            this.pathToClasses = pathToClasses;
            this.name = name;
            this.skinDir = skinDir;
        }
    }
}