Animal Test Pack - Full Proper + Robots
========================================

This is the full proper Animal Test Pack with future robot data included.

It includes:
- Block ID 60 = Wool
- Block IDs 61-68 = wool color variants
- Sheep animal data
- New baby names
- Crystal Sheep entity profile
- Crystal Sheep auto-spawn settings
- /animalpack command
- /crystalsheep command using spawnEntity:crystal_sheep
- /wool command using giveBlock:Wool
- /crystalwool command using giveBlock:Crystal Wool
- Mod recipe examples
- content/robots.json and data/robots.json for future robot support

Robots included as data only:
- worker_bot
- guard_bot
- broken_bot

Important:
Robots are just future data. The engine does not need to use them yet.
They are stored separately from normal entities so they can wait until robot support exists.

Recipes:
- 62 + 60 + 66 = 68
  Blue Wool + Wool + Golden Wool = Crystal Wool

- 61 + 62 = 67
  Pink Wool + Blue Wool = Magenta Wool

- 3x3 Wool grid = Crystal Wool

Install:
  Put this zip in expansion_packs/

Upload path:
  modUI/packs/animal_test_full_proper_robots.zip

ui.store entry:
  {
    "name": "Animal Test Pack - Full Proper + Robots",
    "description": "Adds Wool block ID 60, wool variants, sheep data, baby names, recipes, Crystal Sheep entity support, and future robot data.",
    "url": "https://alaricholt677.github.io/modUI/packs/animal_test_full_proper_robots.zip"
  }
