﻿$p=Join-Path $env:LOCALAPPDATA "Win12MagentaGlassAnimated\cursor-backup.reg"
if(Test-Path $p){reg import $p|Out-Null;Add-Type 'using System;using System.Runtime.InteropServices;public class R{[DllImport("user32.dll")]public static extern bool SystemParametersInfo(uint a,uint b,IntPtr c,uint d);}';[R]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,3)|Out-Null;Write-Host "Previous cursors restored." -ForegroundColor Green}else{Write-Host "No backup found." -ForegroundColor Yellow}
pause
