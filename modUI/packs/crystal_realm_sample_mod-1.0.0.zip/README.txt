
Crystal Realm Sample Mod

Features
--------
- Crystal Cave biome
- Mushroom Cave biome
- Blood Hell Cave biome
- Crystal Realm dimension
- Blood Moon dimension
- Example commands

Installation
------------
1. Put this ZIP in expansion_packs
2. Start IRL Simulator
3. Explore new chunks
4. Use:
   /crystalrealm
   /bloodmoon

Notes
-----
Dimension IDs:
3 = Crystal Realm
4 = Blood Moon

Make sure those IDs are not used
by another custom dimension.
