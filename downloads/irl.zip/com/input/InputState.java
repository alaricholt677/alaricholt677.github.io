package com.input;

public final class InputState {
    public volatile boolean w, a, s, d;
    public volatile boolean breakClick;
    public volatile boolean placeClick;

    public volatile int selectedSlot = 0; // 0..8

    public void consumeClicks() {
        breakClick = false;
        placeClick = false;
    }
}
