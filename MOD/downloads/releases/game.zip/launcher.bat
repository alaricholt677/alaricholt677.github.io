@echo off
setlocal enabledelayedexpansion
title CIRCUS_OS_INTEGRATED_SHELL
color 0A

echo --- [ENCODING_REALITY_INTO_JAR] ---
if not exist "bin" mkdir "bin"

:: 1. COLLECT ALL FILES INTO A QUOTED LIST
set "source_files="
for /r "src" %%f in (*.java) do (
    set "source_files=!source_files! "%%f""
)

if "!source_files!"=="" (
    color 0C
    echo [ERROR]: NO .JAVA FILES FOUND.
    pause
    exit
)

:: 2. COMPILE
javac -d bin !source_files!

if %ERRORLEVEL% NEQ 0 (
    color 0C
    echo [CRITICAL_ERROR]: COMPILATION_FAILED.
    pause
    exit
)

:: 3. JAR PACKAGING
jar cfe DigitalCircus.jar com.circus.main.Main -C bin .
cls

:TERMINAL
echo.
echo  Digital Circus [Version 4.5.2026]
echo  (c) 2026 Caine-Soft Corporation. All rights reserved.
echo.

:PROMPT
:: Reset input to prevent "unexpected at this time" errors
set "user_input="
set /p "user_input=C:\DIGITAL_CIRCUS> "

:: IF INPUT IS EMPTY, RE-PROMPT
if "!user_input!"=="" goto PROMPT

:: --- COMMAND: HELP (Wrapped in quotes to handle dots) ---
if /i "!user_input!"=="help" (
    echo.
    echo  DIR         - Lists all .java source files.
    echo  TYPE [path] - Reads the code of a file.
    echo  START       - Launches the 3D Engine.
    echo  FORCE_STOP  - Kills the Java process.
    echo  CLS         - Clears the terminal.
    echo  EXIT        - Closes the shell.
    echo.
    goto PROMPT
)

:: --- COMMAND: DIR ---
if /i "!user_input!"=="dir" (
    echo.
    for /r "src" %%f in (*.java) do (
        echo  [FILE] "%%~nxf"   -   %%~zf bytes
    )
    echo.
    goto PROMPT
)

:: --- COMMAND: TYPE (Advanced substring handling) ---
set "cmd_check=!user_input:~0,4!"
if /i "!cmd_check!"=="type" (
    set "filepath=!user_input:~5!"
    :: Remove quotes if the user added them manually
    set "filepath=!filepath:"=!"
    if exist "!filepath!" (
        echo.
        echo --- [PREVIEWING: !filepath!] ---
        type "!filepath!"
        echo.
    ) else (
        echo [ERROR]: File "!filepath!" not found.
    )
    goto PROMPT
)

:: --- COMMAND: START ---
if /i "!user_input!"=="start" (
    echo.
    set /p "alias=INITIALIZING... PLEASE ENTER YOUR NAME: "
    echo Launching DigitalCircus.jar as [!alias!]...
    start "CIRCUS_ENGINE" java -jar DigitalCircus.jar --name "!alias!"
    goto PROMPT
)

:: --- COMMAND: FORCE_STOP ---
if /i "!user_input!"=="force_stop" (
    echo Attempting to terminate the simulation...
    taskkill /F /IM java.exe /T >nul 2>&1
    echo [STATUS]: SIMULATION_TERMINATED.
    goto PROMPT
)

:: --- UTILITY COMMANDS ---
if /i "!user_input!"=="cls" ( cls & goto TERMINAL )
if /i "!user_input!"=="exit" exit

:: --- FALLBACK ---
echo '!user_input!' is not recognized as a command. Type 'help'.
goto PROMPT