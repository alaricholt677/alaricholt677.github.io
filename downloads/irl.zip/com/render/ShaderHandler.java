package com.render;

import java.awt.Color;
import com.init.GroxHelper; // New Helper Import

public final class ShaderHandler {

    public Color shade(Color base, double light01) {
        light01 = clamp01(light01);

        // --- GROX VISUAL INJECTION ---
        // We apply the Grox filters to the base color before shading.
        // This ensures the Pink Sky and Purple Grass survive the shader.
        base = GroxHelper.getColor(base, false); 

        int r = (int)Math.round(base.getRed()   * light01);
        int g = (int)Math.round(base.getGreen() * light01);
        int b = (int)Math.round(base.getBlue()  * light01);

        // tiny contrast lift so cubes read better
        r = clamp255((int)(r * 1.05));
        g = clamp255((int)(g * 1.05));
        b = clamp255((int)(b * 1.05));

        return new Color(r, g, b);
    }

    private static double clamp01(double v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
    private static int clamp255(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }
}