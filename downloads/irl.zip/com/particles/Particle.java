package com.particles;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Particle {

    public double x, y, z;
    public double vx, vy, vz;
    public double life;
    public Color color;

    private static final List<Particle> particles = new ArrayList<>();

    public static void add(Particle p) {
        particles.add(p);
    }

    public static void update(double dt) {
        List<Particle> dead = new ArrayList<>();

        for (Particle p : particles) {
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;

            p.vy -= 4.0 * dt; // gravity

            p.life -= dt;
            if (p.life <= 0) dead.add(p);
        }

        particles.removeAll(dead);
    }

    public static List<Particle> getParticles() {
        return particles;
    }

    // Always brown splatter
    public static void spawnBreakEffect(double x, double y, double z) {
        int count = 20;

        for (int i = 0; i < count; i++) {
            Particle p = new Particle();

            p.x = x;
            p.y = y;
            p.z = z;

            p.vx = (Math.random() - 0.5) * 2.0;
            p.vy = (Math.random() - 0.5) * 2.0 + 0.4;
            p.vz = (Math.random() - 0.5) * 2.0;

            p.life = 0.3 + Math.random() * 0.3;

            // Always brown
            p.color = new Color(120, 72, 40);

            add(p);
        }
    }
}
