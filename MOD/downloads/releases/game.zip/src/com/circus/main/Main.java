package com.circus.main;
import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        String identity = "User";
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("--name") && i + 1 < args.length) identity = args[i+1];
        }

        System.out.println("--- [CIRCUS_OS_v4.5_ULTIMATE] ---");
        System.out.println("--- [WELCOME: " + identity + "] ---");

        JFrame frame = new JFrame("The Amazing Digital Circus - 3D Engine");
        Engine engine = new Engine();
        
        // We removed the manual 'new Caine()' calls here 
        // because we added them to the Engine() constructor in the last step!

        frame.add(engine);
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        engine.start();
    }
}