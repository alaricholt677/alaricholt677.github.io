@echo off
setlocal ENABLEDELAYEDEXPANSION

echo === DEBUG: raw command line ===
echo %*
echo.

rem Print each token as seen by CMD
set i=0
:tokloop
if "%~1"=="" goto tokdone
set /a i+=1
echo token !i!: [%~1]
shift
goto tokloop
:tokdone
echo.
echo total tokens: %i%
echo.
rem Print environment info
echo Current directory: %CD%
echo PATH first match for emu.bat:
where emu.bat 2>nul || echo (where returned nothing)
echo.
endlocal
