@echo off
title Emulator Executor
echo [EXECUTOR] Writing path.txt...
if "%~1"=="" (
    echo No .emulator file provided.
    pause
    exit /b 1
)
echo %~1> "%~dp0path.txt"

echo [EXECUTOR] Running converter.py...
"%LOCALAPPDATA%\Programs\Python\Python313\python.exe" "%~dp0converter.py"
if %errorlevel% neq 0 (
    echo Converter failed. Check errors.log
    pause
    exit /b 1
)

echo [EXECUTOR] Running app.py...
"%LOCALAPPDATA%\Programs\Python\Python313\python.exe" "%~dp0app.py"
pause
