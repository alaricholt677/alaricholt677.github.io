package com.circus.entities;

import com.circus.world.CircusGrounds;
import java.awt.Color;
import java.util.Random;
import java.util.ArrayList;

public class Entity {
    public String name;
    public double x, z, y = 100;
    public Color skinColor;
    
    // AI STATE VARIABLES
    private double targetX, targetZ;
    private long lastStateChange = 0;
    private String currentState = "WANDER";
    private Entity chaseTarget = null;
    private Random rand = new Random();

    public Entity(String name, Color color, double x, double z) {
        this.name = name;
        this.skinColor = color;
        this.x = x;
        this.z = z;
        setNewWanderTarget();
    }

    private void setNewWanderTarget() {
        targetX = rand.nextInt(2000) - 1000;
        targetZ = rand.nextInt(2000) + 500;
    }

    public void think(ArrayList<Entity> allEntities) {
        long now = System.currentTimeMillis();

        // 1. STATE SWITCHER (Every 10 Seconds)
        if (now - lastStateChange > 10000) {
            lastStateChange = now;
            if (rand.nextBoolean()) {
                currentState = "CHASE";
                // Pick a random friend to chase
                if (allEntities.size() > 1) {
                    do { chaseTarget = allEntities.get(rand.nextInt(allEntities.size())); } 
                    while (chaseTarget == this);
                }
            } else {
                currentState = "WANDER";
                setNewWanderTarget();
            }
        }

        // 2. MOVEMENT LOGIC
        double speed = (currentState.equals("CHASE")) ? 8.0 : 3.0;
        double tx = (currentState.equals("CHASE") && chaseTarget != null) ? chaseTarget.x : targetX;
        double tz = (currentState.equals("CHASE") && chaseTarget != null) ? chaseTarget.z : targetZ;

        // Move towards target
        double dx = tx - x;
        double dz = tz - z;
        double dist = Math.sqrt(dx*dx + dz*dz);

        if (dist > 5) {
            x += (dx / dist) * speed;
            z += (dz / dist) * speed;
        } else if (currentState.equals("WANDER")) {
            setNewWanderTarget(); // Pick new spot if reached
        }

        // 3. OBJECT INTERACTION (Play with nearby structures)
        // If near the Center Ring (0, 1000), "Jump" for fun
        double distToRing = Math.sqrt(Math.pow(x, 2) + Math.pow(z - 1000, 2));
        if (distToRing < 400) {
            y = 100 - (Math.abs(Math.sin(now * 0.01)) * 50); // Bouncing in the ring!
        } else {
            y = 100; // Walk on ground
        }
    }
}