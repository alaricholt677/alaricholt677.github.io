DinoPack for IRL Simulator

Install:
1. Put DinoPack.zip in your game's expansion_packs folder.
2. Start/load the world.
3. Use /dinohelp or /dinomenu if your command loader supports pack commands.

Includes:
- 8 dino-themed blocks
- 10 dinosaur entities
- recipes, menus, commands, block actions, entity actions, custom AI, animals, baby names, lights, and science data

Main block IDs:
201 Fossil Block
202 Amber Ore
203 Dino Nest
204 Dino Egg
205 Ancient Fern
206 Cretaceous Soil
207 Dino Bone Pile
208 Volcanic Dino Stone
