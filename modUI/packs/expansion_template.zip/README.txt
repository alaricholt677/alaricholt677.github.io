Expansion Pack Template
=======================

Pack ID: expansion_template
Version: 1.0.0

Description:
A starter template for making your own IRL Simulator expansion pack. Includes example folders, manifest examples, block data examples, and readme files.

This is a starter/template expansion zip for the IRL Simulator Mod Store.
Your current store UI downloads packs into the expansion_packs folder.

Suggested future install flow:
1. Download this zip.
2. Verify pack_manifest.json.
3. Read data/*.json.
4. Import only safe data into your engine.
5. Never run downloaded Java code automatically.
