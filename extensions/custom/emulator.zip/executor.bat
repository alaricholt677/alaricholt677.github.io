@echo off
title Emulator Executor
echo [EXECUTOR] Writing path.txt...
if "%~1"=="" (
    echo No .emulator file provided.
    pause
    exit /b 1
)
echo %~1> "C:\Users\alari\Desktop\path.txt"

echo [EXECUTOR] Running converter.py...
"C:\Users\alari\AppData\Local\Programs\Python\Python313\python.exe" "C:\Users\alari\Desktop\converter.py"
if %errorlevel% neq 0 (
    echo Converter failed. Check errors.log
    pause
    exit /b 1
)

echo [EXECUTOR] Running app.py...
"C:\Users\alari\AppData\Local\Programs\Python\Python313\python.exe" "C:\Users\alari\Desktop\app.py"
pause