Robot Entities Extension Pack
=============================

This pack adds robot entity profiles.

Important:
- content/entities.json contains the robots so your current mod entity engine can register them.
- content/robots.json also contains the robots as a future robot-specific data file.
- The engine does not need a special robot system yet.
- They will render using GenericModEntity with template blocky_humanoid unless you later add blocky_robot rendering.

Entities included:
- worker_bot
- guard_bot
- broken_bot
- scout_bot
- heavy_bot

Commands included:
- /robotpack
- /workerbot
- /guardbot
- /brokenbot
- /scoutbot
- /heavybot

Install:
  Put this zip in expansion_packs/

Upload path:
  modUI/packs/robot_entities_extension_pack.zip

ui.store entry:
  {
    "name": "Robot Entities Extension Pack",
    "description": "Adds Worker Bot, Guard Bot, Broken Bot, Scout Bot, and Heavy Bot entity profiles.",
    "url": "https://alaricholt677.github.io/modUI/packs/robot_entities_extension_pack.zip"
  }
