@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Restore-Previous-Cursors.ps1"
