package com.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// Import Main so we can access Main.USER_NAME
import main.Main;

public final class ChatOverlay {

    private boolean open = false;
    private final StringBuilder input = new StringBuilder();
    private final List<String> lines = new ArrayList<>();

    private final Random rand = new Random();

    public ChatOverlay() {
        // matches Engine.java: new ChatOverlay();
    }

    public boolean isOpen() { 
        return open; 
    }

    public void toggle() {
        open = !open;
        if (!open) input.setLength(0);
    }

    public void onKeyTyped(char ch) {
        if (!open) return;
        if (ch >= 32 && ch <= 126) input.append(ch);
    }

    public void onKeyPressed(int keyCode) {
        if (!open) return;

        if (keyCode == KeyEvent.VK_BACK_SPACE) {
            if (input.length() > 0) input.deleteCharAt(input.length() - 1);

        } else if (keyCode == KeyEvent.VK_ENTER) {

            String msg = input.toString().trim();
            input.setLength(0);

            if (!msg.isEmpty()) {

                // PLAYER MESSAGE
                push("<" + Main.USER_NAME + "> " + msg);

                if (msg.startsWith("/")) {
                    runCommand(msg);
                } else {
                    // AI REPLY
                    push("<AI> " + aiReply(msg));
                }
            }

        } else if (keyCode == KeyEvent.VK_ESCAPE) {
            open = false;
            input.setLength(0);
        }
    }

    // -------------------------
    // COMMANDS (VISUAL ONLY)
    // -------------------------
    private void runCommand(String msg) {
        String[] p = msg.split(" ");

        if (p[0].equalsIgnoreCase("/help")) {
            push("<System> Commands: /tp x y z, /give id, /pos, /help");
            return;
        }

        if (p[0].equalsIgnoreCase("/pos")) {
            push("<System> Position: (engine-controlled, not exposed to chat)");
            return;
        }

        if (p[0].equalsIgnoreCase("/tp")) {
            if (p.length == 4) {
                push("<System> (simulated) would teleport to " + p[1] + " " + p[2] + " " + p[3]);
            } else {
                push("<System> Usage: /tp 10 5 10");
            }
            return;
        }

        if (p[0].equalsIgnoreCase("/give")) {
            if (p.length == 2) {
                push("<System> (simulated) would give item id " + p[1] + " to current slot");
            } else {
                push("<System> Usage: /give 5");
            }
            return;
        }

        push("<System> Unknown command. Type /help");
    }

    // -------------------------
    // SIMPLE AI
    // -------------------------
    private String aiReply(String msg) {
        msg = msg.toLowerCase();

        if (msg.contains("hi") || msg.contains("hello"))
            return random("Hey!", "Hello!", "Hi there.", "Yo.");

        if (msg.contains("how are"))
            return random("I'm alright.", "Pretty good.", "Just wandering.", "Can't complain.");

        if (msg.contains("bye"))
            return random("See ya.", "Later.", "Goodbye.", "Take care.");

        return random("Interesting.", "Hmm.", "Okay.", "I see.", "Alright.");
    }

    private String random(String... list) {
        return list[rand.nextInt(list.length)];
    }

    // -------------------------
    // DRAW + HISTORY
    // -------------------------
    public void push(String s) {
        lines.add(s);
        while (lines.size() > 8) lines.remove(0);
    }

    public void draw(Graphics g, int w, int h) {
        int x = 12;
        int y = h - 120;

        g.setColor(new Color(0, 0, 0, 140));
        g.fillRoundRect(x - 6, y - 70, 520, 110, 10, 10);

        g.setColor(Color.WHITE);
        int yy = y - 44;
        for (String line : lines) {
            g.drawString(line, x, yy);
            yy += 14;
        }

        if (open) {
            g.setColor(new Color(0, 0, 0, 180));
            g.fillRoundRect(x - 6, y + 10, 520, 26, 10, 10);
            g.setColor(Color.WHITE);
            g.drawString("> " + input, x, y + 28);
        } else {
            g.setColor(new Color(255, 255, 255, 140));
            g.drawString("Press T to chat", x, y + 28);
        }
    }
}
