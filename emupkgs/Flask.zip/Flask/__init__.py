
import re

def convert(text: str) -> str:
    lines = text.splitlines()

    out = []
    out.append("from flask import Flask, request, jsonify, render_template_string, send_from_directory")
    out.append("app = Flask(__name__)")
    out.append("")

    for line in lines:
        s = line.strip()

        if not s:
            continue

        # ignore import line
        if s.startswith("import mini_flask"):
            continue

        # passthrough everything
        out.append(s)

    # ensure app runs if user forgot
    out.append("")
    out.append("if __name__ == '__main__':")
    out.append("    app.run(host='0.0.0.0', port=5000, debug=False)")

    return "\n".join(out)


def combine(text: str) -> str:
    return text.strip() + "\n"
