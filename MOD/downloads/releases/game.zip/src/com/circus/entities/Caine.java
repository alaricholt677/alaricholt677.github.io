package com.circus.entities;
import java.awt.Color;
import java.util.ArrayList;

public class Caine extends Entity {
    public Caine(String name, double x, double z) {
        // Now passing Name, Color, X, and Z to the base Entity
        super(name, Color.RED, x, z);
    }

    @Override
    public void think(ArrayList<Entity> allEntities) {
        // This now calls the massive wandering/chasing logic in Entity.java
        super.think(allEntities);
    }
}