@echo off
setlocal EnableExtensions
title IRL Simulator - Identity Launcher

:: ==================================================
:: IRL Simulator Pro Launcher
:: Refixed version
:: Pauses on errors / end
:: ==================================================

set "JAR_NAME=IRLSimulator.jar"
set "SKIN_FOLDER=assets\skins"
set "JAVA_MEMORY=-Xms512m -Xmx2G"
set "LOG_FILE=crash-log.txt"

:start
cls
echo ========================================
echo        IRL SIMULATOR PRO LAUNCHER
echo ========================================
echo.

if not exist "%JAR_NAME%" (
    echo [ERROR] %JAR_NAME% was not found in this folder.
    echo.
    echo Put this launcher in the same folder as:
    echo %JAR_NAME%
    echo.
    pause
    goto end
)

set "PLAYER_NAME="
set /p "PLAYER_NAME=Enter Player Name: "

if "%PLAYER_NAME%"=="" (
    echo.
    echo [ERROR] Name cannot be empty.
    echo.
    pause
    goto start
)

if not exist "%SKIN_FOLDER%" (
    mkdir "%SKIN_FOLDER%"

    if errorlevel 1 (
        echo.
        echo [ERROR] Failed to create skin folder:
        echo %SKIN_FOLDER%
        echo.
        pause
        goto end
    )
)

:: Use PowerShell to safely clean invalid filename characters.
:: This avoids broken batch parsing with symbols like < > | ? *
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$n=$env:PLAYER_NAME; foreach($c in [IO.Path]::GetInvalidFileNameChars()){ $n=$n.Replace($c,'_') }; if(:IsNullOrWhiteSpace($n)){ $n='Player' }; Write-Output $n"`) do set "SKIN_FILE=%%A"

set "SKIN_PATH=%SKIN_FOLDER%\%SKIN_FILE%.png"

if not exist "%SKIN_PATH%" (
    echo [SYSTEM] Generating cool aesthetic skin for %PLAYER_NAME%...
    copy /y nul "%SKIN_PATH%" >nul

    if errorlevel 1 (
        echo.
        echo [ERROR] Failed to create placeholder skin:
        echo %SKIN_PATH%
        echo.
        pause
        goto end
    )
)

cls
echo ========================================
echo        IRL SIMULATOR PRO LAUNCHER
echo ========================================
echo.
echo Launching %JAR_NAME%...
echo ----------------------------------------
echo NAME:      %PLAYER_NAME%
echo JAR:       %JAR_NAME%
echo MEMORY:    %JAVA_MEMORY%
echo SKIN:      %SKIN_PATH%
echo VERSION:   1.0.0
echo LOG:       %LOG_FILE%
echo ----------------------------------------
echo.

echo ===== IRL Simulator Crash Log ===== > "%LOG_FILE%"
echo Date: %date% %time% >> "%LOG_FILE%"
echo JAR: %JAR_NAME% >> "%LOG_FILE%"
echo Player: %PLAYER_NAME% >> "%LOG_FILE%"
echo Memory: %JAVA_MEMORY% >> "%LOG_FILE%"
echo Skin: %SKIN_PATH% >> "%LOG_FILE%"
echo. >> "%LOG_FILE%"

java %JAVA_MEMORY% -cp "%JAR_NAME%" main.Main --PathToClasses "." --Name "%PLAYER_NAME%" --skinDir "%SKIN_FOLDER%" --version "1.0.0" >> "%LOG_FILE%" 2>&1

set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo ========================================
    echo [ERROR] IRL Simulator crashed.
    echo Exit Code: %EXIT_CODE%
    echo.
    echo Crash log saved to:
    echo %LOG_FILE%
    echo.
    echo Showing crash log:
    echo ========================================
    echo.

    type "%LOG_FILE%"

    echo.
    echo ========================================
    echo If you see:
    echo java.lang.OutOfMemoryError: Java heap space
    echo.
    echo Try changing:
    echo set "JAVA_MEMORY=-Xms512m -Xmx2G"
    echo.
    echo To:
    echo set "JAVA_MEMORY=-Xms1G -Xmx4G"
    echo ========================================
    echo.
    pause
    goto end
)

echo.
echo ========================================
echo IRL Simulator closed normally.
echo ========================================
pause

:end
echo.
echo Launcher finished.
pause