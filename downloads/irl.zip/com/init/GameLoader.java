package com.init;

import java.io.File;

public class GameLoader {

    public static void runBootSequence(String pathToClasses, String name, String skinDir) {
        File classesPath = new File(pathToClasses);
        if (!classesPath.exists()) {
            throw new RuntimeException("BOOT FAILURE: PathToClasses not found: " + pathToClasses);
        }

        File skinPath = new File(skinDir);
        if (!skinPath.exists() || !skinPath.isDirectory()) {
            throw new RuntimeException("BOOT FAILURE: Skin Directory not found");
        }

        File root = new File(System.getProperty("user.dir"));
        File configs = new File(root, "configs");
        if (!configs.exists()) {
            if (!configs.mkdirs()) {
                throw new RuntimeException("BOOT FAILURE: Could not create /configs/");
            }
        }
    }
}
