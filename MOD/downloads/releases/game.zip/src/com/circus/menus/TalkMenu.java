package com.circus.menus;
import com.circus.main.Engine;
import com.circus.ai.CircusBrain;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class TalkMenu extends CircusMenu {
    private TextBox input;
    private ArrayList<String> logs = new ArrayList<>();

    public TalkMenu(Engine engine) {
        input = new TextBox(100, 600, 1080, 40);
        this.elements.add(input);
        logs.add("[SYSTEM]: Circus Chat Initialized.");
    }

// Inside TalkMenu.java, find the key() method and update:
@Override
public void key(KeyEvent e) {
    super.key(e); 
    if (e.getKeyCode() == KeyEvent.VK_ENTER && !input.text.isEmpty()) {
        String msg = input.text;
        logs.add("[YOU]: " + msg);
        
        // Use getResponse instead of processChat
        String aiResponse = com.circus.ai.CircusBrain.getResponse("CAINE", msg, "Alari");
        logs.add(aiResponse);
        
        input.text = ""; 
    }
}
    @Override
    public void draw(Graphics2D g2) {
        g2.setColor(new Color(20, 20, 40, 200));
        g2.fillRect(50, 50, 1180, 620);
        
        g2.setFont(new Font("Consolas", Font.PLAIN, 16));
        int y = 550;
        for (int i = logs.size() - 1; i >= 0 && y > 100; i--) {
            g2.setColor(logs.get(i).contains("[YOU]") ? Color.CYAN : Color.YELLOW);
            g2.drawString(logs.get(i), 100, y);
            y -= 25;
        }
        
        for (UIElement el : elements) el.draw(g2);
    }
}