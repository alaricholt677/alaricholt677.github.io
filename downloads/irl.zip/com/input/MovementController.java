package com.input;

import com.world.World;

public final class MovementController {

    public double x, y, z;

    private double vy = 0;

    private static final double MOVE_SPEED = 6.0;
    private static final double GRAVITY = 18.0;
    private static final double EYE_HEIGHT = 1.7;
    private static final double GROUND_EPS = 0.02;

    public MovementController(double startX, double startZ, World world) {
        x = startX;
        z = startZ;
        y = world.surfaceHeight(x, z) + EYE_HEIGHT;
    }

    public void update(World world, InputState in, double yaw, double dt) {
        double forward = 0.0;
        double strafe = 0.0;

        if (in.w) forward += 1.0;
        if (in.s) forward -= 1.0;
        if (in.d) strafe += 1.0;
        if (in.a) strafe -= 1.0;

        double mag = Math.sqrt(forward * forward + strafe * strafe);
        if (mag > 1e-9) {
            forward /= mag;
            strafe /= mag;
        }

        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);

        double vx = (forward * sin + strafe * cos) * MOVE_SPEED;
        double vz = (forward * cos - strafe * sin) * MOVE_SPEED;

        vy -= GRAVITY * dt;

        x += vx * dt;
        y += vy * dt;
        z += vz * dt;

        double ground = world.surfaceHeight(x, z) + EYE_HEIGHT;
        if (y < ground + GROUND_EPS) {
            y = ground;
            vy = 0.0;
        }
    }
}
