package com.circus.entities;

import java.awt.Color;
import java.util.ArrayList;

public class Zooble extends Entity { // MUST BE 'Zooble'
    public Zooble(String name, double x, double z) {
        super(name, new Color(120, 80, 200), x, z); 
        // Purple-ish chaotic Zooble palette
    }

    @Override
    public void think(ArrayList<Entity> allEntities) {
        super.think(allEntities);
        // Add Zooble-specific logic later if needed
    }
}
