"""
OS plugin for Emulator.

This plugin is meant to be the "core OS compiler" layer.
It sees the entire .emulator file (after imports are stripped)
and can reshape or wrap it before other plugins or before final output.
"""

import re
from pathlib import Path

def convert(source_text: str) -> str:
    """
    Core OS-level convert step.

    Right now this:
      - Normalizes line endings
      - Strips trailing spaces
      - Keeps all lines so other plugins can still see everything

    You can extend this later to:
      - Handle OS-level directives
      - Preprocess global settings
      - Inject boilerplate
    """
    lines = source_text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    cleaned = [line.rstrip() for line in lines]
    return "\n".join(cleaned)


def combine(final_text: str) -> str:
    """
    Final OS-level combiner.

    Wraps the final transformed DSL/Python into a runnable shell
    that matches your converter.py expectations: it produces app.py
    that can be executed directly.

    You can extend this to:
      - Scan for window definitions
      - Auto-generate main() logic
      - Integrate with EmulatorOS runtime more deeply
    """
    header = (
        "import tkinter as tk\n"
        "from pathlib import Path\n"
        "from os_runtime import EmulatorOS\n\n"
    )

    body = final_text.rstrip() + "\n\n"

    footer = (
        "def main():\n"
        "    # TODO: hook into EmulatorOS, create windows, etc.\n"
        "    # For now, this just defines the environment and leaves\n"
        "    # the transformed code above to run at import time.\n"
        "    pass\n\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )

    return header + body + footer
