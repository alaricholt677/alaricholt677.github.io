package main;

import com.entities.BaseEntity;
import com.render.ShaderHandler;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class _3DEngine {

    public static final int W = 960;
    public static final int H = 540;

    private static final double FOV_DEG = 78.0;
    private static final double NEAR = 0.06;

    private final BufferedImage frame = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
    private final int[] pixels = ((java.awt.image.DataBufferInt) frame.getRaster().getDataBuffer()).getData();

    private final ShaderHandler shader = new ShaderHandler();

    // Cached reflection for Triangle
    private Field triI0, triI1, triI2;
    private Field triColor;

    public enum ViewType { PERSPECTIVE }

    public BufferedImage getFrame() { return frame; }

    public void beginFrame() {
        int sky = new Color(120, 170, 255).getRGB();
        for (int i = 0; i < pixels.length; i++) pixels[i] = sky;
    }

    public void renderEntities(List<BaseEntity> entities,
                               double camX, double camY, double camZ,
                               double yaw, double pitch,
                               ViewType viewType) {

        if (entities == null || entities.isEmpty()) return;

        // Camera rotation (world -> camera): rotate world by -yaw then -pitch
        final double sinY = Math.sin(yaw), cosY = Math.cos(yaw);
        final double sinP = Math.sin(pitch), cosP = Math.cos(pitch);

        // Projection scale
        final double f = (H * 0.5) / Math.tan(Math.toRadians(FOV_DEG) * 0.5);

        List<RTri> tris = new ArrayList<>(entities.size() * 256);

        for (BaseEntity e : entities) {
            BaseEntity.Mesh m = e.getMesh();
            if (m == null || m.vertices == null || m.triangles == null || m.triangles.isEmpty()) continue;

            double ex = e.getX(), ey = e.getY(), ez = e.getZ();

            for (BaseEntity.Triangle t : m.triangles) {
                ensureTriangleReflection(t);

                int ia = getTriIndex(t, triI0);
                int ib = getTriIndex(t, triI1);
                int ic = getTriIndex(t, triI2);
                if (ia < 0 || ib < 0 || ic < 0) continue;
                if (ia >= m.vertices.size() || ib >= m.vertices.size() || ic >= m.vertices.size()) continue;

                BaseEntity.Vertex a0 = m.vertices.get(ia);
                BaseEntity.Vertex b0 = m.vertices.get(ib);
                BaseEntity.Vertex c0 = m.vertices.get(ic);

                // World space
                double axw = a0.x + ex, ayw = a0.y + ey, azw = a0.z + ez;
                double bxw = b0.x + ex, byw = b0.y + ey, bzw = b0.z + ez;
                double cxw = c0.x + ex, cyw = c0.y + ey, czw = c0.z + ez;

                // Translate to camera origin
                double ax = axw - camX, ay = ayw - camY, az = azw - camZ;
                double bx = bxw - camX, by = byw - camY, bz = bzw - camZ;
                double cx = cxw - camX, cy = cyw - camY, cz = czw - camZ;

                // Yaw inverse
                double ax1 = ax * cosY - az * sinY;
                double az1 = ax * sinY + az * cosY;

                double bx1 = bx * cosY - bz * sinY;
                double bz1 = bx * sinY + bz * cosY;

                double cx1 = cx * cosY - cz * sinY;
                double cz1 = cx * sinY + cz * cosY;

                // Pitch inverse
                double ay2 = ay * cosP - az1 * sinP;
                double az2 = ay * sinP + az1 * cosP;

                double by2 = by * cosP - bz1 * sinP;
                double bz2 = by * sinP + bz1 * cosP;

                double cy2 = cy * cosP - cz1 * sinP;
                double cz2 = cy * sinP + cz1 * cosP;

                // Near reject
                if (az2 < NEAR && bz2 < NEAR && cz2 < NEAR) continue;

                // Normal in camera space
                double abx = bx1 - ax1, aby = by2 - ay2, abz = bz2 - az2;
                double acx = cx1 - ax1, acy = cy2 - ay2, acz = cz2 - az2;

                double nx = aby * acz - abz * acy;
                double ny = abz * acx - abx * acz;
                double nz = abx * acy - aby * acx;

                // Backface cull (camera looks down +Z)
                if (nz >= 0) continue;

                // Lighting (directional)
                double lx = -0.35, ly = -0.85, lz = -0.40;
                double nLen = Math.sqrt(nx * nx + ny * ny + nz * nz);
                double lLen = Math.sqrt(lx * lx + ly * ly + lz * lz);
                double ndotl = 0.0;
                if (nLen > 1e-9) ndotl = (nx * lx + ny * ly + nz * lz) / (nLen * lLen);
                double light = clamp01(0.18 + Math.max(0.0, -ndotl) * 0.92);

                // Project
                Proj pa = project(ax1, ay2, az2, f);
                Proj pb = project(bx1, by2, bz2, f);
                Proj pc = project(cx1, cy2, cz2, f);
                if (!pa.ok || !pb.ok || !pc.ok) continue;

                double zAvg = (az2 + bz2 + cz2) / 3.0;

                Color base = getTriColor(t);
                int rgb = shader.shade(base, light).getRGB();

                tris.add(new RTri(pa.sx, pa.sy, pb.sx, pb.sy, pc.sx, pc.sy, zAvg, rgb));
            }
        }

        tris.sort(Comparator.comparingDouble(a -> -a.z));

        Graphics2D g = frame.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);

        for (RTri t : tris) {
            g.setColor(new Color(t.rgb));
            g.fillPolygon(new int[]{t.ax, t.bx, t.cx}, new int[]{t.ay, t.by, t.cy}, 3);
        }

        g.dispose();
    }

    private void ensureTriangleReflection(BaseEntity.Triangle t) {
        if (triI0 != null) return;

        // Pick first 3 int fields as indices, and first Color field as color
        Field[] fs = t.getClass().getDeclaredFields();

        List<Field> ints = new ArrayList<>(3);
        for (Field f : fs) {
            f.setAccessible(true);
            if (f.getType() == int.class) ints.add(f);
            if (triColor == null && f.getType() == Color.class) triColor = f;
        }

        if (ints.size() >= 3) {
            triI0 = ints.get(0);
            triI1 = ints.get(1);
            triI2 = ints.get(2);
        } else {
            // Leave nulls; indices will fail safely
            triI0 = triI1 = triI2 = null;
        }
    }

    private int getTriIndex(BaseEntity.Triangle t, Field f) {
        if (f == null) return -1;
        try { return f.getInt(t); } catch (Exception ignored) { return -1; }
    }

    private Color getTriColor(BaseEntity.Triangle t) {
        if (triColor == null) return Color.WHITE;
        try {
            Object o = triColor.get(t);
            return (o instanceof Color) ? (Color) o : Color.WHITE;
        } catch (Exception ignored) {
            return Color.WHITE;
        }
    }

    private static Proj project(double x, double y, double z, double f) {
        if (z < NEAR) return new Proj(0, 0, false);

        double invZ = 1.0 / z;
        int sx = (int) Math.round(W * 0.5 + x * f * invZ);
        int sy = (int) Math.round(H * 0.5 - y * f * invZ);

        boolean ok = (sx > -W && sx < W * 2 && sy > -H && sy < H * 2);
        return new Proj(sx, sy, ok);
    }

    private static double clamp01(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    private static final class Proj {
        final int sx, sy;
        final boolean ok;
        Proj(int sx, int sy, boolean ok) { this.sx = sx; this.sy = sy; this.ok = ok; }
    }

    private static final class RTri {
        final int ax, ay, bx, by, cx, cy;
        final double z;
        final int rgb;
        RTri(int ax, int ay, int bx, int by, int cx, int cy, double z, int rgb) {
            this.ax = ax; this.ay = ay; this.bx = bx; this.by = by; this.cx = cx; this.cy = cy;
            this.z = z; this.rgb = rgb;
        }
    }
}
