WIN12 MAGENTA GLASS ANIMATED

Extract the ZIP, then run Apply-Animated-Glass.cmd.
All 15 Windows pointer roles use 12-frame ANI animation.
The glass highlight and glow are clipped to each cursor silhouette, so no particles or trails leave the cursor shape.
Run Restore-Previous-Cursors.cmd to undo.
Original concept pack; not an official Microsoft product.
