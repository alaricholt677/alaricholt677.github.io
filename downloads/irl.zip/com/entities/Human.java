package com.entities;

import java.awt.Color;
import java.util.Random;

public class Human extends BaseEntity {

    private enum State {
        WANDER,
        TAG
    }

    private State state = State.WANDER;

    private double targetX;
    private double targetZ;

    private int wanderTimer = 0;
    private int nextWanderDelay = 0;

    private int tagTimer = 0;
    private int nextTagDelay = 0;

    private final Random rand = new Random();

    public Human() {
        rebuildVoxelHumanMesh();
        pickNewWanderTarget();

        // Random delay before first tag attempt
        nextTagDelay = 400 + rand.nextInt(400);
    }

    @Override
    public void tick() {

        // Stay grounded
        if (y < 0) y = 0;

        // TAG MODE TIMER
        tagTimer++;
        if (state == State.WANDER && tagTimer >= nextTagDelay) {
            tryStartTagMode();
        }

        switch (state) {

            case WANDER -> {
                wanderTimer++;

                if (wanderTimer >= nextWanderDelay) {
                    pickNewWanderTarget();
                }

                moveToward(targetX, targetZ, 0.05);
            }

            case TAG -> {
                // Move faster in tag mode
                moveToward(targetX, targetZ, 0.08);

                // If close to target, exit tag mode
                double dx = targetX - x;
                double dz = targetZ - z;
                if (Math.sqrt(dx * dx + dz * dz) < 0.5) {
                    exitTagMode();
                }
            }
        }
    }

    private void tryStartTagMode() {
        tagTimer = 0;
        nextTagDelay = 400 + rand.nextInt(400);

        // 50% chance to enter tag mode
        if (rand.nextBoolean()) {
            state = State.TAG;

            // Pick a fast random direction
            targetX = x + (rand.nextDouble() * 30 - 15);
            targetZ = z + (rand.nextDouble() * 30 - 15);
        }
    }

    private void exitTagMode() {
        state = State.WANDER;
        pickNewWanderTarget();
    }

    private void pickNewWanderTarget() {
        wanderTimer = 0;
        nextWanderDelay = 100 + rand.nextInt(200);

        targetX = x + (rand.nextDouble() * 20 - 10);
        targetZ = z + (rand.nextDouble() * 20 - 10);
    }

    private void moveToward(double tx, double tz, double speed) {
        double dx = tx - x;
        double dz = tz - z;

        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 0.01) return;

        x += (dx / dist) * speed;
        z += (dz / dist) * speed;
    }

    // ------------------------------------------------------------
    // VOXEL MESH (UNCHANGED)
    // ------------------------------------------------------------
    private void rebuildVoxelHumanMesh() {
        Mesh m = getMesh();
        m.vertices.clear();
        m.triangles.clear();

        Color skin  = new Color(210, 170, 140);
        Color shirt = new Color(60, 110, 200);
        Color pants = new Color(40, 40, 55);
        Color shoes = new Color(25, 25, 25);

        addCube(m, -1, 6, -1,   2, 2, 2, skin);
        addCube(m, -1, 3, -0.5, 2, 3, 1, shirt);
        addCube(m, -2, 3, -0.5, 1, 3, 1, shirt);
        addCube(m,  1, 3, -0.5, 1, 3, 1, shirt);
        addCube(m, -1, 0, -0.5, 1, 3, 1, pants);
        addCube(m,  0, 0, -0.5, 1, 3, 1, pants);
        addCube(m, -1, -1, -0.5, 1, 1, 1, shoes);
        addCube(m,  0, -1, -0.5, 1, 1, 1, shoes);
    }

    private void addCube(Mesh m, double x, double y, double z,
                         double sx, double sy, double sz, Color c) {

        double x0 = x,     x1 = x + sx;
        double y0 = y,     y1 = y + sy;
        double z0 = z,     z1 = z + sz;

        addQuad(m, x0,y1,z0,  x1,y1,z0,  x1,y1,z1,  x0,y1,z1, c);
        addQuad(m, x0,y0,z0,  x0,y0,z1,  x1,y0,z1,  x1,y0,z0, c);
        addQuad(m, x0,y0,z0,  x1,y0,z0,  x1,y1,z0,  x0,y1,z0, c);
        addQuad(m, x0,y0,z1,  x0,y1,z1,  x1,y1,z1,  x1,y0,z1, c);
        addQuad(m, x1,y0,z0,  x1,y0,z1,  x1,y1,z1,  x1,y1,z0, c);
        addQuad(m, x0,y0,z0,  x0,y1,z0,  x0,y1,z1,  x0,y0,z1, c);
    }

    private void addQuad(Mesh m,
                         double ax, double ay, double az,
                         double bx, double by, double bz,
                         double cx, double cy, double cz,
                         double dx, double dy, double dz,
                         Color col) {

        int base = m.vertices.size();

        m.vertices.add(new Vertex(ax, ay, az));
        m.vertices.add(new Vertex(bx, by, bz));
        m.vertices.add(new Vertex(cx, cy, cz));
        m.vertices.add(new Vertex(dx, dy, dz));

        m.triangles.add(new Triangle(base, base + 1, base + 2, col));
        m.triangles.add(new Triangle(base, base + 2, base + 3, col));
    }
}
