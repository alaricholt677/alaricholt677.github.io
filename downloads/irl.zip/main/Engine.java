package main;

import com.config.LevelOptions;
import com.entities.BaseEntity;
import com.entities.Human;
import com.input.InputState;
import com.input.MovementController;
import com.save.EntitiesAliveSave;
import com.save.PlayerSave;
import com.ui.ChatOverlay;
import com.ui.MenuManager;
import com.world.Voxel;
import com.world.World;
import com.particles.Particle;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Engine implements MouseListener, MouseMotionListener, KeyListener {

    private final JFrame window;
    private final RenderPanel renderPanel;

    private final _3DEngine renderer = new _3DEngine();
    private final MenuManager menu;

    private final InputState input = new InputState();
    private final ChatOverlay chat = new ChatOverlay();

    private final List<BaseEntity> dynamicEntities = new ArrayList<>();
    private final List<Human> humans = new ArrayList<>();

    private World world;
    private File currentLevelDir;

    private double yaw = 0.0, pitch = 0.0;
    private MovementController movement;

    // Mouse look: click+drag to look, release stops.
    private boolean didDragLook = false;
    private int pressX = 0, pressY = 0;
    private int lastMouseX = 0, lastMouseY = 0;
    private static final int DRAG_THRESHOLD_PX = 4;
    private final double mouseSensitivity = 0.0045;

    // Hotbar stores “what you broke / what you’re placing” per slot
    private final byte[] hotbar = new byte[9];

    // Crosshair
    private BufferedImage crosshairImg;

    // Autosave
    private long lastAutosaveNs = System.nanoTime();
    private static final long AUTOSAVE_INTERVAL_NS = 10_000_000_000L; // 10 seconds

    // Ray origin tuning (eye height)
    private static final double EYE_HEIGHT = 1.62;

    // Selection highlight (white overlay cube)
    private final BaseEntity selectionEntity = new BaseEntity() { @Override public void tick() {} };
    private final List<BaseEntity> selectionList = Collections.singletonList(selectionEntity);
    private int selX = Integer.MIN_VALUE, selY = Integer.MIN_VALUE, selZ = Integer.MIN_VALUE;

    public Engine() {
        window = new JFrame("IRL SIMULATOR 3D - " + Main.USER_NAME);
        renderPanel = new RenderPanel();

        renderPanel.setPreferredSize(new Dimension(_3DEngine.W, _3DEngine.H));
        renderPanel.setFocusable(true);

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setContentPane(renderPanel);

        menu = new MenuManager(window, this);

        renderPanel.addMouseListener(this);
        renderPanel.addMouseMotionListener(this);
        renderPanel.addKeyListener(this);

        installKeyBindings();

        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);

        try {
            crosshairImg = ImageIO.read(Engine.class.getResourceAsStream("/com/resources/crosshair.png"));
        } catch (Exception ignored) {
            crosshairImg = null;
        }

        clearSelection();
        SwingUtilities.invokeLater(() -> renderPanel.requestFocusInWindow());
    }

    // Called by MenuManager
    public void loadLevel(File levelDir, LevelOptions opts) {
        currentLevelDir = levelDir;

        world = new World(4);
        world.applyOptions(opts);
        world.loadFromLevelDir(levelDir);

        // Load player
        try {
            File f = new File(new File(levelDir, "playerpos"), "playerpos.dat");
            PlayerSave.PlayerData pd = PlayerSave.load(f);

            movement = new MovementController(0.0, 0.0, world);
            if (pd.x != 0 || pd.y != 0 || pd.z != 0) {
                movement.x = pd.x;
                movement.y = pd.y;
                movement.z = pd.z;
            }

            input.selectedSlot = clamp(pd.selectedSlot, 0, 8);
            hotbar[0] = pd.slot0; hotbar[1] = pd.slot1; hotbar[2] = pd.slot2;
            hotbar[3] = pd.slot3; hotbar[4] = pd.slot4; hotbar[5] = pd.slot5;
            hotbar[6] = pd.slot6; hotbar[7] = pd.slot7; hotbar[8] = pd.slot8;
        } catch (Exception ignored) {
            movement = new MovementController(0.0, 0.0, world);
        }

        // Load humans
        humans.clear();
        dynamicEntities.clear();
        try {
            File f = new File(new File(levelDir, "humanalive"), "entitiesAlive.dat");
            humans.addAll(EntitiesAliveSave.load(f));
        } catch (Exception ignored) {}

        if (humans.isEmpty()) {
            Human h1 = new Human(); h1.setPosition(0, 0, 10);  humans.add(h1);
            Human h2 = new Human(); h2.setPosition(4, 0, 14);  humans.add(h2);
            Human h3 = new Human(); h3.setPosition(-5, 0, 16); humans.add(h3);
        }

        dynamicEntities.addAll(humans);

        chat.push("Loaded: " + levelDir.getName());
        lastAutosaveNs = System.nanoTime();

        clearSelection();
        renderPanel.requestFocusInWindow();
    }

    public void saveCurrentLevel() {
        if (world == null || currentLevelDir == null || movement == null) return;

        world.saveToLevelDir(currentLevelDir);

        try {
            PlayerSave.PlayerData pd = new PlayerSave.PlayerData();
            pd.x = movement.x; pd.y = movement.y; pd.z = movement.z;
            pd.selectedSlot = input.selectedSlot;

            pd.slot0 = hotbar[0]; pd.slot1 = hotbar[1]; pd.slot2 = hotbar[2];
            pd.slot3 = hotbar[3]; pd.slot4 = hotbar[4]; pd.slot5 = hotbar[5];
            pd.slot6 = hotbar[6]; pd.slot7 = hotbar[7]; pd.slot8 = hotbar[8];

            File f = new File(new File(currentLevelDir, "playerpos"), "playerpos.dat");
            PlayerSave.save(f, pd);
        } catch (Exception ignored) {}

        try {
            File f = new File(new File(currentLevelDir, "humanalive"), "entitiesAlive.dat");
            EntitiesAliveSave.save(f, humans);
        } catch (Exception ignored) {}

        chat.push("Saved.");
    }

    private void installKeyBindings() {
        InputMap im = renderPanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = renderPanel.getActionMap();

        bind(im, am, "W_P", KeyStroke.getKeyStroke("pressed W"), () -> input.w = true);
        bind(im, am, "W_R", KeyStroke.getKeyStroke("released W"), () -> input.w = false);

        bind(im, am, "A_P", KeyStroke.getKeyStroke("pressed A"), () -> input.a = true);
        bind(im, am, "A_R", KeyStroke.getKeyStroke("released A"), () -> input.a = false);

        bind(im, am, "S_P", KeyStroke.getKeyStroke("pressed S"), () -> input.s = true);
        bind(im, am, "S_R", KeyStroke.getKeyStroke("released S"), () -> input.s = false);

        bind(im, am, "D_P", KeyStroke.getKeyStroke("pressed D"), () -> input.d = true);
        bind(im, am, "D_R", KeyStroke.getKeyStroke("released D"), () -> input.d = false);

        bind(im, am, "SAVE", KeyStroke.getKeyStroke("pressed F5"), this::saveCurrentLevel);

        for (int i = 0; i < 9; i++) {
            int slot = i;
            bind(im, am, "SLOT_" + (i + 1), KeyStroke.getKeyStroke("pressed " + (i + 1)), () -> input.selectedSlot = slot);
        }

        bind(im, am, "CHAT", KeyStroke.getKeyStroke("pressed T"), chat::toggle);

        // Block interaction on keys
        bind(im, am, "BREAK_KEY", KeyStroke.getKeyStroke("pressed B"), this::breakBlockKey);
        bind(im, am, "PLACE_KEY", KeyStroke.getKeyStroke("pressed P"), this::placeBlockKey);
    }

    private void bind(InputMap im, ActionMap am, String name, KeyStroke ks, Runnable r) {
        im.put(ks, name);
        am.put(name, new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { r.run(); }
        });
    }

public void start() {
    final double fixedDt = 1.0 / 60.0;
    long last = System.nanoTime();
    double acc = 0.0;

    // --- GROX INITIALIZATION ---
    com.init.GroxHelper.initialize();

    while (true) {
        long now = System.nanoTime();
        double frameDt = (now - last) / 1_000_000_000.0;
        last = now;

        if (frameDt > 0.25) frameDt = 0.25;
        acc += frameDt;

        if (menu.isPlaying() && world != null && movement != null) {
            while (acc >= fixedDt) {
                tickFixed(fixedDt);

                // --- GROX ENTITY POSITION OVERRIDE (SAFE COPY) ---
                if (com.init.GroxHelper.isGrox) {
                    // iterate over a snapshot so changes to dynamicEntities won't break anything
                    List<com.entities.BaseEntity> groxSnapshot = new ArrayList<>(dynamicEntities);
                    for (com.entities.BaseEntity e : groxSnapshot) {
                        double[] pos = com.init.GroxHelper.getSpawn(
                                movement.x,
                                movement.y + EYE_HEIGHT,
                                movement.z,
                                yaw
                        );
                        if (pos != null) {
                            e.setPosition(pos[0], pos[1], pos[2]);
                        }
                    }
                }

                acc -= fixedDt;
            }

            long nowNs = System.nanoTime();
            if (nowNs - lastAutosaveNs >= AUTOSAVE_INTERVAL_NS) {
                saveCurrentLevel();
                lastAutosaveNs = nowNs;
            }
        } else {
            acc = 0.0;
        }

        renderer.beginFrame();

        if (world != null && movement != null) {
            var currentView = menu.getViewType();

            // SAFE SNAPSHOT FOR VISIBLE WORLD ENTITIES
            List<com.entities.BaseEntity> visible = world.visibleMeshes(movement.x, movement.z, yaw);
            List<com.entities.BaseEntity> visibleSnapshot = new ArrayList<>(visible);

            // SAFE SNAPSHOT FOR DYNAMIC ENTITIES
            List<com.entities.BaseEntity> dynamicSnapshot = new ArrayList<>(dynamicEntities);

            // 1. Render World
            renderer.renderEntities(
                    visibleSnapshot,
                    movement.x, movement.y + EYE_HEIGHT, movement.z,
                    yaw, pitch,
                    currentView
            );

            // 2. Render Dynamic Entities
            renderer.renderEntities(
                    dynamicSnapshot,
                    movement.x, movement.y + EYE_HEIGHT, movement.z,
                    yaw, pitch,
                    currentView
            );

            // 3. Selection Highlight (selectionList is immutable singleton, safe)
            if (selX != Integer.MIN_VALUE) {
                renderer.renderEntities(
                        selectionList,
                        movement.x, movement.y + EYE_HEIGHT, movement.z,
                        yaw, pitch,
                        currentView
                );
            }
        }

        renderPanel.repaint();

        try { Thread.sleep(2); } catch (InterruptedException ignored) {}
    }
}

    private void tickFixed(double dt) {
        movement.update(world, input, yaw, dt);

        // YAW-ONLY 5-block “line” selection
        updateSelectionYawLine();

        for (BaseEntity e : dynamicEntities) e.tick();
    }

    // =========================
    // KEY-DRIVEN BLOCK ACTIONS
    // =========================

private void breakBlockKey() {
    if (!menu.isPlaying() || world == null || movement == null) return;
    if (chat.isOpen()) return;

    // No selected block
    if (selX == Integer.MIN_VALUE) return;

    byte t = world.getBlock(selX, selY, selZ);
    if (t == Voxel.AIR) return;

    // Break the selected block
    world.setBlock(selX, selY, selZ, Voxel.AIR);

    // Store in hotbar
    hotbar[input.selectedSlot] = t;

    // --- PARTICLE SPLATTER EFFECT (brown) ---
    double px = selX + 0.5;
    double py = selY + 0.5;
    double pz = selZ + 0.5;

    // NEW signature: no blockType argument
    Particle.spawnBreakEffect(px, py, pz);

    // Clear highlight after breaking
    clearSelection();

    renderPanel.repaint();
}


private void placeBlockKey() {
    if (!menu.isPlaying() || world == null || movement == null) return;
    if (chat.isOpen()) return;

    // No selected block
    if (selX == Integer.MIN_VALUE) return;

    byte t = hotbar[input.selectedSlot];
    if (t == Voxel.AIR) return;

    // Direction from camera
    double cy = Math.cos(pitch);
    double dx = Math.sin(yaw) * cy;
    double dy = -Math.sin(pitch);
    double dz = Math.cos(yaw) * cy;

    // Start with selected block
    int px = selX;
    int py = selY;
    int pz = selZ;

    // Determine which axis the player is pointing at strongest
    double ax = Math.abs(dx);
    double ay = Math.abs(dy);
    double az = Math.abs(dz);

    // FIXED: Correct face selection (no more opposite placement)
    if (ax >= ay && ax >= az) {
        px += (dx > 0) ? 1 : -1;   // X face
    } else if (ay >= ax && ay >= az) {
        py += (dy > 0) ? 1 : -1;   // Y face
    } else {
        pz += (dz > 0) ? 1 : -1;   // Z face
    }

    // Only place if empty
    if (world.getBlock(px, py, pz) != Voxel.AIR) return;

    world.setBlock(px, py, pz, t);

    // Keep hotbar behavior the same
    hotbar[input.selectedSlot] = t;

    renderPanel.repaint();
}

    // =========================
    // YAW-ONLY 5-BLOCK LINE SELECTION
    // =========================

private void updateSelectionYawLine() {
    if (!menu.isPlaying() || world == null || movement == null) {
        clearSelection();
        return;
    }

    // Eye origin
    double ox = movement.x;
    double oy = movement.y + EYE_HEIGHT;
    double oz = movement.z;

    // Yaw-only forward direction
    double dx = Math.sin(yaw);
    double dz = Math.cos(yaw);

    // EXACT: 5 blocks forward
    int maxBlocks = 5;

    // We step in small increments so we don't skip thin targets
    double step = 0.05;

    // Check multiple vertical slices so selection actually hits blocks
    // (eye level, one below, two below)
    int[] yOffsets = { 0, -1, -2 };

    int lastX = Integer.MIN_VALUE, lastY = Integer.MIN_VALUE, lastZ = Integer.MIN_VALUE;

    for (double t = 0.0; t <= maxBlocks; t += step) {
        double px = ox + dx * t;
        double pz = oz + dz * t;

        int wx = (int) Math.floor(px);
        int wz = (int) Math.floor(pz);

        for (int yo : yOffsets) {
            int wy = (int) Math.floor(oy) + yo;

            // de-dupe repeated same cell checks
            if (wx == lastX && wy == lastY && wz == lastZ) continue;
            lastX = wx; lastY = wy; lastZ = wz;

            if (world.getBlock(wx, wy, wz) != Voxel.AIR) {
                if (wx != selX || wy != selY || wz != selZ) {
                    selX = wx; selY = wy; selZ = wz;
                    rebuildSelectionMesh(wx, wy, wz);
                }
                return;
            }
        }
    }

    clearSelection();
}

    // =========================
    // SELECTION HIGHLIGHT MESH
    // =========================

    private void clearSelection() {
        selX = selY = selZ = Integer.MIN_VALUE;
        var m = selectionEntity.getMesh();
        m.vertices.clear();
        m.triangles.clear();
        selectionEntity.setPosition(0, 0, 0);
    }

    private void rebuildSelectionMesh(int wx, int wy, int wz) {
        selectionEntity.setPosition(wx, wy, wz);

        var m = selectionEntity.getMesh();
        m.vertices.clear();
        m.triangles.clear();

        // Slightly inflated cube so it doesn’t z-fight with the block faces
        double e = 0.002;

        double x0 = -e, y0 = -e, z0 = -e;
        double x1 = 1 + e, y1 = 1 + e, z1 = 1 + e;

        int v0 = addV(m, x0, y0, z0);
        int v1 = addV(m, x1, y0, z0);
        int v2 = addV(m, x1, y1, z0);
        int v3 = addV(m, x0, y1, z0);

        int v4 = addV(m, x0, y0, z1);
        int v5 = addV(m, x1, y0, z1);
        int v6 = addV(m, x1, y1, z1);
        int v7 = addV(m, x0, y1, z1);

        Color white = new Color(255, 255, 255);

        // Front (z0)
        tri(m, v0, v1, v2, white); tri(m, v0, v2, v3, white);
        // Back (z1)
        tri(m, v5, v4, v7, white); tri(m, v5, v7, v6, white);
        // Left (x0)
        tri(m, v4, v0, v3, white); tri(m, v4, v3, v7, white);
        // Right (x1)
        tri(m, v1, v5, v6, white); tri(m, v1, v6, v2, white);
        // Top (y1)
        tri(m, v3, v2, v6, white); tri(m, v3, v6, v7, white);
        // Bottom (y0)
        tri(m, v4, v5, v1, white); tri(m, v4, v1, v0, white);
    }

    private int addV(BaseEntity.Mesh m, double x, double y, double z) {
        int idx = m.vertices.size();
        m.vertices.add(new BaseEntity.Vertex(x, y, z));
        return idx;
    }

    private void tri(BaseEntity.Mesh m, int a, int b, int c, Color col) {
        m.triangles.add(new BaseEntity.Triangle(a, b, c, col));
    }

    // =========================
    // RAYCAST (USED FOR BREAK/PLACE)
    // =========================

    private Hit raycastBlock(double maxDist) {
        double ox = movement.x;
        double oy = movement.y + EYE_HEIGHT;
        double oz = movement.z;

        double cy = Math.cos(pitch);
        double dx = Math.sin(yaw) * cy;
        double dy = -Math.sin(pitch);
        double dz = Math.cos(yaw) * cy;

        double step = 0.08;
        double t = 0.0;

        int lastX = Integer.MIN_VALUE, lastY = Integer.MIN_VALUE, lastZ = Integer.MIN_VALUE;

        while (t <= maxDist) {
            double px = ox + dx * t;
            double py = oy + dy * t;
            double pz = oz + dz * t;

            int wx = (int)Math.floor(px);
            int wy = (int)Math.floor(py);
            int wz = (int)Math.floor(pz);

            if (wx != lastX || wy != lastY || wz != lastZ) {
                if (world.getBlock(wx, wy, wz) != Voxel.AIR) return new Hit(wx, wy, wz);
                lastX = wx; lastY = wy; lastZ = wz;
            }

            t += step;
        }
        return null;
    }

    private PlaceHit raycastPlace(double maxDist) {
        double ox = movement.x;
        double oy = movement.y + EYE_HEIGHT;
        double oz = movement.z;

        double cy = Math.cos(pitch);
        double dx = Math.sin(yaw) * cy;
        double dy = -Math.sin(pitch);
        double dz = Math.cos(yaw) * cy;

        double step = 0.08;
        double t = 0.0;

        int prevX = Integer.MIN_VALUE, prevY = Integer.MIN_VALUE, prevZ = Integer.MIN_VALUE;

        while (t <= maxDist) {
            double px = ox + dx * t;
            double py = oy + dy * t;
            double pz = oz + dz * t;

            int wx = (int)Math.floor(px);
            int wy = (int)Math.floor(py);
            int wz = (int)Math.floor(pz);

            if (world.getBlock(wx, wy, wz) != Voxel.AIR) {
                if (prevX != Integer.MIN_VALUE) return new PlaceHit(prevX, prevY, prevZ);
                return null;
            }

            prevX = wx; prevY = wy; prevZ = wz;
            t += step;
        }
        return null;
    }

    private static final class Hit {
        final int wx, wy, wz;
        Hit(int wx, int wy, int wz) { this.wx = wx; this.wy = wy; this.wz = wz; }
    }

    private static final class PlaceHit {
        final int wx, wy, wz;
        PlaceHit(int wx, int wy, int wz) { this.wx = wx; this.wy = wy; this.wz = wz; }
    }

    private int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

    private void clampPitch() {
        double maxPitch = Math.toRadians(80);
        if (pitch < -maxPitch) pitch = -maxPitch;
        if (pitch > maxPitch) pitch = maxPitch;
    }

    private final class RenderPanel extends JPanel {
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(renderer.getFrame(), 0, 0, null);

            if (movement != null) {
                menu.drawHUD(g, movement.x, movement.y, movement.z);
                drawHotbar(g);
                chat.draw(g, getWidth(), getHeight());
                drawCrosshair(g);
            }
        }

        private void drawHotbar(Graphics g) {
            int w = getWidth();
            int y = getHeight() - 48;
            int x0 = w / 2 - (9 * 44) / 2;

            for (int i = 0; i < 9; i++) {
                boolean sel = (i == input.selectedSlot);
                g.setColor(sel ? new Color(255, 255, 255, 220) : new Color(0, 0, 0, 160));
                g.fillRoundRect(x0 + i * 44, y, 40, 40, 8, 8);

                g.setColor(Color.WHITE);
                g.drawRoundRect(x0 + i * 44, y, 40, 40, 8, 8);

                byte t = hotbar[i];
                g.drawString(String.valueOf(t), x0 + i * 44 + 16, y + 24);
            }
        }

        private void drawCrosshair(Graphics g) {
            int cx = getWidth() / 2;
            int cy = getHeight() / 2;

            if (crosshairImg != null) {
                int w = crosshairImg.getWidth();
                int h = crosshairImg.getHeight();
                g.drawImage(crosshairImg, cx - w / 2, cy - h / 2, null);
            } else {
                g.setColor(Color.WHITE);
                g.drawLine(cx - 6, cy, cx + 6, cy);
                g.drawLine(cx, cy - 6, cx, cy + 6);
            }
        }
    }

    // =========================
    // MOUSE LOOK (DRAG ONLY)
    // =========================

    @Override public void mousePressed(MouseEvent e) {
        if (!menu.isPlaying() || world == null || movement == null) return;

        pressX = e.getX();
        pressY = e.getY();
        didDragLook = false;
    }

    @Override public void mouseReleased(MouseEvent e) {}

    @Override public void mouseDragged(MouseEvent e) {
        if (!menu.isPlaying() || world == null || movement == null) return;

        int mx = e.getX();
        int my = e.getY();

        int dx0 = mx - pressX;
        int dy0 = my - pressY;

        if (!didDragLook) {
            if (Math.abs(dx0) >= DRAG_THRESHOLD_PX || Math.abs(dy0) >= DRAG_THRESHOLD_PX) {
                didDragLook = true;
                lastMouseX = mx;
                lastMouseY = my;
                renderPanel.requestFocusInWindow();
            } else {
                return;
            }
        }

        int dx = mx - lastMouseX;
        int dy = my - lastMouseY;

        yaw += dx * mouseSensitivity;
        pitch += dy * mouseSensitivity;

        clampPitch();

        lastMouseX = mx;
        lastMouseY = my;
    }

    @Override public void mouseMoved(MouseEvent e) {}

    // =========================
    // KEY LISTENER (CHAT INPUT)
    // =========================

    @Override public void keyTyped(KeyEvent e) { chat.onKeyTyped(e.getKeyChar()); }
    @Override public void keyPressed(KeyEvent e) { chat.onKeyPressed(e.getKeyCode()); }
    @Override public void keyReleased(KeyEvent e) {}

    @Override public void mouseClicked(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
}
