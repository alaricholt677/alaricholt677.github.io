 package com.ui;

import com.config.LevelManager;
import com.config.LevelOptions;
import main.Engine;
import main._3DEngine;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.File;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class MenuManager {

    private final JFrame window;
    private final Engine engine;

    private boolean playing = false;
    private _3DEngine.ViewType viewType = _3DEngine.ViewType.PERSPECTIVE;

    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);

    // Level UI state
    private DefaultListModel<LevelManager.LevelEntry> levelModel = new DefaultListModel<>();
    private JList<LevelManager.LevelEntry> levelList = new JList<>(levelModel);
    private JTextField searchField = new JTextField();

    // Options UI state
    private JCheckBox optOcclusion = new JCheckBox("Occlusion culling", true);
    private JCheckBox optStreaming = new JCheckBox("Unrender/render chunks (streaming)", true);
    private JCheckBox optMeshing = new JCheckBox("Chunk meshing (EXPERIMENTAL)", false);
    private JSpinner optRenderDist = new JSpinner(new SpinnerNumberModel(6, 1, 16, 1));

    private File pendingLevelDir;
    private String pendingLevelName;

    public MenuManager(JFrame window, Engine engine) {
        this.window = window;
        this.engine = engine;

        root.setOpaque(false);
        root.add(buildMainMenu(), "main");
        root.add(buildLevelMenu(), "levels");
        root.add(buildOptionsMenu(), "options");
        root.add(buildMultiplayerMenu(), "multiplayer");

        window.setGlassPane(root);
        root.setVisible(true);

        showMain();
    }

    public boolean isPlaying() { 
        return playing; 
    }

    public _3DEngine.ViewType getViewType() { 
        return viewType; 
    }

    public void drawHUD(Graphics g, double x, double y, double z) {
        g.setColor(Color.WHITE);
        g.drawString("X: " + (int)x + "  Y: " + (int)y + "  Z: " + (int)z, 12, 18);
        g.drawString("LMB: dig  RMB: place last broken  F5: save", 12, 36);
    }

    // ----------------------------------------------------
    // MAIN MENU
    // ----------------------------------------------------
    private JPanel buildMainMenu() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(true);
        p.setBackground(new Color(0, 0, 0, 180));

        JButton play = new JButton("Play");
        play.setPreferredSize(new Dimension(220, 44));
        play.addActionListener(e -> showLevels());

        JButton multiplayer = new JButton("Multiplayer");
        multiplayer.setPreferredSize(new Dimension(220, 44));
        multiplayer.addActionListener(e -> showMultiplayer());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.gridx = 0; 
        c.gridy = 0;
        p.add(label("IRL SIMULATOR", 28), c);

        c.gridy = 1;
        p.add(play, c);

        c.gridy = 2;
        p.add(multiplayer, c);

        return p;
    }

    // ----------------------------------------------------
    // LEVEL MENU (SINGLEPLAYER)
    // ----------------------------------------------------
    private JPanel buildLevelMenu() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setOpaque(true);
        p.setBackground(new Color(0, 0, 0, 180));
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel top = new JPanel(new BorderLayout(8, 8));
        top.setOpaque(false);

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { refreshLevels(); }
            @Override public void removeUpdate(DocumentEvent e) { refreshLevels(); }
            @Override public void changedUpdate(DocumentEvent e) { refreshLevels(); }
        });

        top.add(label("Saved levels", 20), BorderLayout.WEST);
        top.add(searchField, BorderLayout.CENTER);

        levelList.setCellRenderer((list, value, index, isSelected, cellHasFocus) -> {
            JLabel l = new JLabel(value.name);
            l.setOpaque(true);
            l.setForeground(Color.WHITE);
            l.setBackground(isSelected ? new Color(70, 120, 220, 180) : new Color(20, 20, 20, 160));
            l.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
            return l;
        });

        JScrollPane scroll = new JScrollPane(levelList);
        scroll.setPreferredSize(new Dimension(420, 320));

        JPanel buttons = new JPanel(new GridLayout(2, 3, 8, 8));
        buttons.setOpaque(false);

        JButton create = new JButton("Create new level");
        JButton play = new JButton("Play level");
        JButton edit = new JButton("Edit level");
        JButton rename = new JButton("Rename");
        JButton delete = new JButton("Delete");
        JButton back = new JButton("Back");

        create.addActionListener(e -> createLevelFlow());
        play.addActionListener(e -> playSelected());
        edit.addActionListener(e -> editSelected());
        rename.addActionListener(e -> renameSelected());
        delete.addActionListener(e -> deleteSelected());
        back.addActionListener(e -> showMain());

        buttons.add(create);
        buttons.add(play);
        buttons.add(edit);
        buttons.add(rename);
        buttons.add(delete);
        buttons.add(back);

        p.add(top, BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);

        return p;
    }

    // ----------------------------------------------------
    // OPTIONS MENU
    // ----------------------------------------------------
    private JPanel buildOptionsMenu() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(true);
        p.setBackground(new Color(0, 0, 0, 180));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.gridx = 0; 
        c.gridy = 0; 
        c.gridwidth = 2;
        p.add(label("Level options", 22), c);

        c.gridwidth = 2; 
        c.gridy++;
        p.add(optOcclusion, c);

        c.gridy++;
        p.add(optStreaming, c);

        c.gridy++;
        p.add(optMeshing, c);

        c.gridwidth = 1; 
        c.gridy++;
        p.add(label("Render distance (chunks)", 14), c);
        c.gridx = 1;
        p.add(optRenderDist, c);

        JButton confirm = new JButton("Confirm");
        JButton cancel = new JButton("Cancel");

        confirm.addActionListener(e -> confirmOptions());
        cancel.addActionListener(e -> showLevels());

        c.gridx = 0; 
        c.gridy++; 
        c.gridwidth = 1;
        p.add(confirm, c);
        c.gridx = 1;
        p.add(cancel, c);

        return p;
    }

    // ----------------------------------------------------
    // MULTIPLAYER MENU
    // ----------------------------------------------------
    private JPanel buildMultiplayerMenu() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(true);
        p.setBackground(new Color(0, 0, 0, 180));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.gridx = 0; 
        c.gridy = 0;
        c.gridwidth = 2;

        p.add(label("Multiplayer", 26), c);

        c.gridy++;
        c.gridwidth = 1;
        p.add(label("Server IP:", 14), c);

        c.gridx = 1;
        JTextField ipField = new JTextField("127.0.0.1:25565", 18);
        p.add(ipField, c);

        c.gridx = 0;
        c.gridy++;
        p.add(label("World URL:", 14), c);

        c.gridx = 1;
        JTextField urlField = new JTextField("https://example.com/world.zip", 18);
        p.add(urlField, c);

        JButton join = new JButton("Join server");
        JButton back = new JButton("Back");

        c.gridx = 0;
        c.gridy++;
        p.add(join, c);

        c.gridx = 1;
        p.add(back, c);

        join.addActionListener(e -> {
            String ip = ipField.getText().trim();
            String url = urlField.getText().trim();
            joinMultiplayer(ip, url);
        });

        back.addActionListener(e -> showMain());

        return p;
    }

    // ----------------------------------------------------
    // VIEW SWITCHING
    // ----------------------------------------------------
    private void showMain() {
        playing = false;
        root.setVisible(true);
        cards.show(root, "main");
    }

    private void showLevels() {
        playing = false;
        refreshLevels();
        root.setVisible(true);
        cards.show(root, "levels");
    }

    private void showOptions(File levelDir, String levelName) {
        pendingLevelDir = levelDir;
        pendingLevelName = levelName;

        LevelOptions o = LevelManager.loadOptions(levelDir);
        optOcclusion.setSelected(o.occlusionCulling);
        optStreaming.setSelected(o.chunkStreaming);
        optMeshing.setSelected(o.chunkMeshing);
        optRenderDist.setValue(o.renderDistanceChunks);

        root.setVisible(true);
        cards.show(root, "options");
    }

    private void showMultiplayer() {
        playing = false;
        root.setVisible(true);
        cards.show(root, "multiplayer");
    }

    // ----------------------------------------------------
    // LEVEL MANAGEMENT
    // ----------------------------------------------------
    private void refreshLevels() {
        levelModel.clear();
        String q = searchField.getText().trim().toLowerCase();

        List<LevelManager.LevelEntry> levels = LevelManager.listLevels();
        for (LevelManager.LevelEntry e : levels) {
            if (q.isEmpty() || e.name.toLowerCase().contains(q)) levelModel.addElement(e);
        }
    }

    private LevelManager.LevelEntry selected() {
        return levelList.getSelectedValue();
    }

    private void createLevelFlow() {
        String name = JOptionPane.showInputDialog(window, "Enter save name:", "Create new level", JOptionPane.PLAIN_MESSAGE);
        if (name == null) return;
        name = name.trim();
        if (name.isEmpty()) return;

        try {
            File dir = LevelManager.createLevel(name);
            showOptions(dir, name);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(window, "Failed to create level:\n" + ex.getMessage());
        }
    }

    private void playSelected() {
        LevelManager.LevelEntry e = selected();
        if (e == null) return;

        LevelOptions o = LevelManager.loadOptions(e.dir);
        engine.loadLevel(e.dir, o);

        playing = true;
        root.setVisible(false);
    }

    private void editSelected() {
        LevelManager.LevelEntry e = selected();
        if (e == null) return;
        showOptions(e.dir, e.name);
    }

    private void renameSelected() {
        LevelManager.LevelEntry e = selected();
        if (e == null) return;

        String name = JOptionPane.showInputDialog(window, "New name:", e.name);
        if (name == null) return;

        try {
            LevelManager.renameLevel(e.dir, name.trim());
            refreshLevels();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(window, "Rename failed:\n" + ex.getMessage());
        }
    }

    private void deleteSelected() {
        LevelManager.LevelEntry e = selected();
        if (e == null) return;

        int ok = JOptionPane.showConfirmDialog(window, "Delete \"" + e.name + "\"?", "Confirm delete", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) return;

        try {
            LevelManager.deleteLevel(e.dir);
            refreshLevels();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(window, "Delete failed:\n" + ex.getMessage());
        }
    }

    private void confirmOptions() {
        if (pendingLevelDir == null) { 
            showLevels(); 
            return; 
        }

        LevelOptions o = new LevelOptions();
        o.occlusionCulling = optOcclusion.isSelected();
        o.chunkStreaming = optStreaming.isSelected();
        o.chunkMeshing = optMeshing.isSelected();
        o.renderDistanceChunks = (Integer) optRenderDist.getValue();

        LevelManager.saveOptions(pendingLevelDir, o);

        engine.loadLevel(pendingLevelDir, o);
        playing = true;
        root.setVisible(false);
    }

    // ----------------------------------------------------
    // MULTIPLAYER JOIN LOGIC
    // ----------------------------------------------------
    private void joinMultiplayer(String ip, String url) {
        try {
            // 1. Download world zip from URL
            File tempZip = new File("temp_multiplayer_world.zip");
            Files.copy(new URL(url).openStream(), tempZip.toPath(), StandardCopyOption.REPLACE_EXISTING);

            // 2. Extract into a dedicated multiplayer world folder
            File worldDir = new File("multiplayer_world");
            unzip(tempZip, worldDir);

            // 3. Load options and start playing
            LevelOptions o = LevelManager.loadOptions(worldDir);
            engine.loadLevel(worldDir, o);

            playing = true;
            root.setVisible(false);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(window, "Failed to join server:\n" + ex.getMessage());
        }
    }

    private void unzip(File zipFile, File destDir) throws Exception {
        destDir.mkdirs();
        try (ZipInputStream zis = new ZipInputStream(new java.io.FileInputStream(zipFile))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                File newFile = new File(destDir, entry.getName());
                if (entry.isDirectory()) {
                    newFile.mkdirs();
                } else {
                    File parent = newFile.getParentFile();
                    if (parent != null) parent.mkdirs();
                    Files.copy(zis, newFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
                zis.closeEntry();
            }
        }
    }

    // ----------------------------------------------------
    // UTIL
    // ----------------------------------------------------
    private JLabel label(String s, int size) {
        JLabel l = new JLabel(s);
        l.setForeground(Color.WHITE);
        l.setFont(l.getFont().deriveFont(Font.BOLD, (float) size));
        return l;
    }
}
