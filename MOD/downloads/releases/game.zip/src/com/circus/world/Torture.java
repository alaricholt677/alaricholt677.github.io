package com.circus.world;

import com.circus.main.ShaderHandler;
import java.awt.*;
import java.util.Random;

public class Torture {

    private final Random rand = new Random();

    public void render(Graphics2D g2, int width, int height,
                       double camX, double camZ, double yaw) {

        int cx = width / 2;
        int cy = height / 2;

        // 1. BLOOD SKYBOX
        g2.setPaint(new GradientPaint(
                0, 0, new Color(30, 0, 0),
                0, cy, new Color(5, 0, 0)
        ));
        g2.fillRect(0, 0, width, height);

        // 2. CORRUPTED GROUND / STRUCTURES (same grid, different skin)
        for (int z = 0; z <= 5000; z += 250) {
            for (int x = -2500; x <= 2500; x += 250) {

                double dx = x - camX;
                double dz = z - camZ;

                double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
                double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);

                if (rz < 50) continue;

                int px = (int)((rx / rz) * 800) + cx;
                int py = (int)((400 / rz) * 800) + cy;
                int size = (int)(15000 / rz);

                double distFactor = Math.max(0.2, 1.0 - (rz / 3000.0));
                Color base = new Color(120 + rand.nextInt(40), 0, 0);
                Color shaded = ShaderHandler.applyShading(base, rz, distFactor);
                g2.setColor(shaded);

                int mode = rand.nextInt(4);
                switch (mode) {
                    case 0: // Cracked plate
                        g2.fillRect(px - size/2, py - size/6, size, size/3);
                        g2.setColor(Color.BLACK);
                        g2.drawLine(px - size/2, py, px + size/2, py);
                        break;

                    case 1: // Jagged spike
                        g2.fillRect(px - size/10, py - size, size/5, size);
                        break;

                    case 2: // Void slit
                        g2.setColor(Color.BLACK);
                        g2.fillRect(px - size/4, py - size/8, size/2, size/4);
                        break;

                    case 3: // Pulsing ring
                        g2.drawOval(px - size/3, py - size/3,
                                    (int)(size * 0.6), (int)(size * 0.6));
                        break;
                }
            }
        }

        // 3. CENTRAL VOID EYE (same projection rules)
        renderVoidEye(g2, width, height, camX, camZ, yaw);

        // 4. REDACTED OVERLAY
        g2.setFont(new Font("Monospaced", Font.BOLD, 100));
        g2.setColor(new Color(255, 0, 0, 40));
        g2.drawString("REDACTED", rand.nextInt(width), rand.nextInt(height));
    }

    private void renderVoidEye(Graphics2D g2, int width, int height,
                               double camX, double camZ, double yaw) {

        int cx = width / 2;
        int cy = height / 2;

        double eyeX = 0;
        double eyeZ = 1500;

        double dx = eyeX - camX;
        double dz = eyeZ - camZ;

        double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
        double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);

        if (rz < 50) return;

        int px = (int)((rx / rz) * 800) + cx;
        int py = (int)((200 / rz) * 800) + cy;
        int size = (int)(30000 / rz);

        Color haloBase = new Color(255, 0, 0);
        Color haloShade = ShaderHandler.applyShading(haloBase, rz, 1.2);
        g2.setColor(new Color(haloShade.getRed(), haloShade.getGreen(), haloShade.getBlue(), 140));
        g2.fillOval(px - size/2 + rand.nextInt(20) - 10,
                    py - size/2 + rand.nextInt(20) - 10,
                    size, size);

        g2.setColor(Color.WHITE);
        g2.fillOval(px - size/5, py - size/5, (int)(size * 0.4), (int)(size * 0.4));

        g2.setColor(Color.BLACK);
        g2.fillOval(px - size/10, py - size/10, (int)(size * 0.2), (int)(size * 0.2));
    }
}
