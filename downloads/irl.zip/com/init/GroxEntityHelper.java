package com.init;

import main.Main;

public class GroxEntityHelper {
    /**
     * Replicates the spawning logic to force a Human entity 
     * exactly 0.5 units in front of the player's face.
     */
    public static double[] getKissingPosition(double pX, double pY, double pZ, double pYaw) {
        if (!"Grox".equalsIgnoreCase(Main.USER_NAME)) return null;

        // Math for spawning directly in front based on looking direction (Yaw)
        double spawnX = pX + (Math.sin(pYaw) * 0.5);
        double spawnZ = pZ + (Math.cos(pYaw) * 0.5);
        
        return new double[] { spawnX, pY, spawnZ };
    }
}