
(function(){'use strict';
function $q(q){return window.jQuery?window.jQuery(q):document.querySelectorAll(q)}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
function waitReady(cb){var tries=0,t=setInterval(function(){tries++;if(window.Win12Plus&&typeof widgets!=='undefined'&&typeof apps!=='undefined'&&window.jQuery){clearInterval(t);cb()}if(tries>160)clearInterval(t)},100)}
waitReady(function(){
var P=window.Win12Plus;
function currentUser(){return P.users().find(function(u){return u.name===P.current()})||P.users()[0]}
function refreshLoginUi(){
  var users=P.users(),cur=P.current(),u=currentUser();
  $q('#loginback>.name').text(u.name);
  $q('#login-password').attr('placeholder',u.pin?'PIN':'No PIN set').toggle(!!u.pin).val('');
  if(!document.getElementById('plus-user-count'))document.body.insertAdjacentHTML('beforeend','<div id="plus-user-count"></div>');
  document.getElementById('plus-user-count').innerHTML='<div>Users: '+users.length+'</div><select id="plus-user-select">'+users.map(function(x){return'<option '+(x.name===cur?'selected':'')+'>'+esc(x.name)+'</option>'}).join('')+'</select><br><a id="plus-new-user">create user</a>'+(u.pin?'<br><span id="plus-pin-status">Enter PIN to login</span><br><a id="plus-forgot-pin">forgot password?</a>':'<br><span id="plus-pin-status">New/no PIN: click Login</span>');
}
P.loginBox=refreshLoginUi;
P.setCurrent=function(n){localStorage.setItem(P.curKey,n);P.ensureUser(n);P.applyExplorer();refreshLoginUi()};
document.addEventListener('change',function(e){if(e.target&&e.target.id==='plus-user-select')P.setCurrent(e.target.value)},true);
document.addEventListener('click',function(e){if(e.target&&e.target.id==='plus-new-user'){P.newUser();refreshLoginUi()} if(e.target&&e.target.id==='plus-forgot-pin')alert('This virtual PIN is stored only in localStorage. Create a new user if forgotten.')},true);
function canLogin(){var u=currentUser();if(!u.pin)return true;var ok=$q('#login-password').val()===u.pin;$q('#plus-pin-status').text(ok?'PIN accepted':'Wrong PIN');return ok}
function removeLoginOverlay(){P.ensureUser(P.current());P.applyExplorer();$q('#loginback').css({'pointer-events':'none','opacity':'0','transition':'opacity .25s ease'});$q('#plus-user-count').css({'opacity':'0','pointer-events':'none','transition':'opacity .25s ease'});setTimeout(function(){$q('#loginback').hide();$q('#plus-user-count').hide()},280)}
var oldLogin=window.win12LoginSubmit;
window.win12LoginSubmit=function(){if(!canLogin())return;var r;try{if(oldLogin)r=oldLogin.apply(window,arguments)}catch(e){console.warn(e)}setTimeout(removeLoginOverlay,120);return r};
document.addEventListener('click',function(e){if(e.target&&e.target.id==='login'){if(canLogin())setTimeout(removeLoginOverlay,80)}},true);
document.addEventListener('keydown',function(e){if(e.key==='Enter'&&document.activeElement&&document.activeElement.id==='login-password'){if(canLogin())setTimeout(removeLoginOverlay,80)}},true);
refreshLoginUi();

function addTemplate(id,title,body){var tpl=document.querySelector('#widgets>.widgets>.content>.template');if(!tpl||tpl.querySelector('.'+id))return;tpl.insertAdjacentHTML('beforeend','<div class="'+id+'"><div class="wg '+id+' plus-card template"><div class="titbar"><a class="a more notip" onclick="J(\'.wg.'+id+'>.titbar>.menu\').toggleClass(\'show\')"><i class="bi bi-three-dots"></i></a><div class="menu"><a class="a addtodt" onclick="widgets.widgets.remove(\''+id+'\');widgets.widgets.addToDesktop(\''+id+'\')"><i class="bi bi-box-arrow-in-right"></i></a><a class="a delete" onclick="widgets.widgets.remove(\''+id+'\')"><i class="bi bi-trash"></i></a></div></div><div class="content" onmousedown="widgetsMove(this.parentElement,event)"><h3>'+title+'</h3>'+body+'</div></div></div>')}
addTemplate('todoPlus','To Do','<input class="todo-in" placeholder="New task"><button class="plus-btn add">Add</button><div class="todo-list"></div>');
addTemplate('launcherPlus','App Launcher','<div class="plus-mini-grid"><button class="plus-btn" data-app="explorer">Explorer</button><button class="plus-btn" data-app="edge">Edge</button><button class="plus-btn" data-app="notepad">Notepad</button><button class="plus-btn" data-app="powershell">PowerShell</button></div>');
addTemplate('fileSearchPlus','VFS Search','<input class="search" placeholder="Search files"><div class="results"></div>');
addTemplate('clipboardPlus','Clipboard','<textarea placeholder="Scratch clipboard" oninput="localStorage.setItem(\'win12.plus.clipboard\',this.value)"></textarea>');
addTemplate('calendarPlus','Calendar','<div class="date" style="font-size:32px"></div><div class="month"></div>');
widgets.todoPlus={init:function(){function render(w){var arr=JSON.parse(localStorage.getItem('win12.plus.todo')||'[]');w.find('.todo-list').html(arr.map(function(t,i){return'<div class="plus-card-small"><input type="checkbox" '+(t.done?'checked':'')+' data-i="'+i+'"> <span style="'+(t.done?'text-decoration:line-through':'')+'">'+esc(t.text)+'</span> <a data-del="'+i+'">x</a></div>'}).join(''))}$q('.wg.todoPlus:not(.template)').each(function(){var w=$q(this);render(w);w.find('.add').off('click').on('click',function(){var input=w.find('.todo-in'),v=input.val().trim();if(!v)return;var arr=JSON.parse(localStorage.getItem('win12.plus.todo')||'[]');arr.push({text:v,done:false});localStorage.setItem('win12.plus.todo',JSON.stringify(arr));input.val('');render(w)});w.off('change.todo').on('change.todo','input[type=checkbox]',function(){var arr=JSON.parse(localStorage.getItem('win12.plus.todo')||'[]'),i=+this.dataset.i;if(arr[i])arr[i].done=this.checked;localStorage.setItem('win12.plus.todo',JSON.stringify(arr));render(w)});w.off('click.todo').on('click.todo','a[data-del]',function(){var arr=JSON.parse(localStorage.getItem('win12.plus.todo')||'[]');arr.splice(+this.dataset.del,1);localStorage.setItem('win12.plus.todo',JSON.stringify(arr));render(w)})})},remove:function(){}};
widgets.launcherPlus={init:function(){$q('.wg.launcherPlus:not(.template) button[data-app]').off('click').on('click',function(){openapp(this.dataset.app)})},remove:function(){}};
widgets.fileSearchPlus={init:function(){function walk(n,b,q,out){Object.keys(n.folder||{}).forEach(function(k){walk(n.folder[k],b+'/'+k,q,out)});(n.file||[]).forEach(function(f){var p=b+'/'+f.name;if(f.name.toLowerCase().indexOf(q)>-1)out.push(p)})}$q('.wg.fileSearchPlus:not(.template) .search').off('input').on('input',function(){var q=this.value.toLowerCase(),out=[];if(q)walk(P.fs(),'C:',q,out);$q(this).closest('.wg').find('.results').html(out.slice(0,10).map(function(p){return'<a onclick="Win12Plus.openPath(\''+p+'\')">'+esc(p)+'</a>'}).join(''))})},remove:function(){}};
widgets.clipboardPlus={init:function(){$q('.wg.clipboardPlus:not(.template) textarea').val(localStorage.getItem('win12.plus.clipboard')||'')},remove:function(){}};
widgets.calendarPlus={h:0,init:function(){clearInterval(widgets.calendarPlus.h);function tick(){var d=new Date();$q('.wg.calendarPlus:not(.template) .date').text(d.getDate());$q('.wg.calendarPlus:not(.template) .month').text(d.toLocaleDateString(undefined,{weekday:'long',month:'long',year:'numeric'}))}tick();widgets.calendarPlus.h=setInterval(tick,60000)},remove:function(){clearInterval(widgets.calendarPlus.h)}};

function dedupeNotice(){var seen={};$q('.notice list.new a').each(function(){var txt=$q(this).text().trim();if(seen[txt])$q(this).remove();else seen[txt]=1});$q('.notice list.new a.plus-widget-option').remove();var opts=[['zerocode','0 Code Widget'],['quicknotes','Quick Notes'],['vfsstats','VFS Stats'],['worldclock','World Clock'],['rssheadlines','News Sources'],['todoPlus','To Do'],['launcherPlus','App Launcher'],['fileSearchPlus','VFS Search'],['clipboardPlus','Clipboard'],['calendarPlus','Calendar']];opts.forEach(function(o){$q('.notice list.new').append('<a class="a plus-widget-option" onclick="closenotice();widgets.widgets.add(\''+o[0]+'\')">'+o[1]+'</a>')});var seen2={};$q('.notice list.new a').each(function(){var txt=$q(this).text().trim();if(seen2[txt])$q(this).remove();else seen2[txt]=1})}
var oldShow=window.shownotice;window.shownotice=function(name){var r=oldShow.apply(window,arguments);if(name==='widgets'){setTimeout(dedupeNotice,90);setTimeout(dedupeNotice,180)}return r};
console.log('Win12 Plus UI/widget/login fixes loaded');
});
})();
