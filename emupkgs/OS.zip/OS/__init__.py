# mini_os FULL SYSTEM

import re


def convert(text: str) -> str:
    out = []

    # ✅ Runtime
    out.append("# Mini OS Runtime")
    out.append("import os")
    out.append("import tkinter as tk")
    out.append("")
    out.append("def open_window(title):")
    out.append("    root = tk.Tk()")
    out.append("    root.title(title)")
    out.append("    root.geometry('300x200')")
    out.append("    label = tk.Label(root, text=title)")
    out.append("    label.pack()")
    out.append("    root.after(100, root.destroy)")  # auto close demo
    out.append("    root.mainloop()")
    out.append("")
    out.append("def write(text):")
    out.append("    print(text)")
    out.append("")
    out.append("def writefile(name, content):")
    out.append("    with open(name, 'w', encoding='utf-8') as f:")
    out.append("        f.write(content)")
    out.append("")
    out.append("def readfile(name):")
    out.append("    try:")
    out.append("        with open(name, 'r', encoding='utf-8') as f:")
    out.append("            return f.read()")
    out.append("    except Exception as e:")
    out.append("        return str(e)")
    out.append("")

    # ✅ Parser
    for line in text.splitlines():
        raw = line.rstrip("\n")

        stripped = raw.lstrip()
        indent = raw[:len(raw) - len(stripped)]

        if not stripped or stripped.startswith("import mini_os"):
            continue

        # ✅ window
        m = re.match(r'window\s+"(.+)"', stripped)
        if m:
            out.append(f"{indent}open_window({repr(m.group(1))})")
            continue

        # ✅ say "text"
        m = re.match(r'say\s+"(.+)"', stripped)
        if m:
            out.append(f"{indent}write({repr(m.group(1))})")
            continue

        # ✅ say variable
        m = re.match(r'say\s+([A-Za-z_][A-Za-z0-9_]*)', stripped)
        if m:
            out.append(f"{indent}write({m.group(1)})")
            continue

        # ✅ write file
        m = re.match(r'writefile\s+"(.+)"\s+"(.+)"', stripped)
        if m:
            out.append(f"{indent}writefile({repr(m.group(1))}, {repr(m.group(2))})")
            continue

        # ✅ read file
        m = re.match(r'readfile\s+"(.+)"', stripped)
        if m:
            out.append(f"{indent}write(readfile({repr(m.group(1))}))")
            continue

        # ✅ if
        if stripped.startswith("if "):
            out.append(f"{indent}{stripped}:")
            continue

        # ✅ while
        if stripped.startswith("while "):
            out.append(f"{indent}{stripped}:")
            continue

        # ✅ else
        if stripped == "else":
            out.append(f"{indent}else:")
            continue

        # ✅ fallback
        out.append(raw)

    return "\n".join(out)


def combine(text: str) -> str:
    return text.strip() + "\n"