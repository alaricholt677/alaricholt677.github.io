package com.circus.main;

import com.circus.entities.*;
import com.circus.world.*;
import com.circus.menus.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Engine extends JPanel implements KeyListener, MouseListener, MouseMotionListener {
    public ArrayList<Entity> entities = new ArrayList<>();
    private CircusGrounds grounds = new CircusGrounds();
    private Torture nightmare = new Torture();
    public double camX = 0, camZ = 0, yaw = 0;
    public CircusMenu activeMenu = null;
    
    private Robot robot;
    private boolean mouseLocked = true;

    public Engine() {
        this.setFocusable(true);
        this.addKeyListener(this);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        
        try { 
            robot = new Robot(); 
        } catch (Exception e) { e.printStackTrace(); }

        // INITIALIZE THE ACTORS WITH 3D COORDINATES (X, Z)
        entities.add(new Caine("CAINE", 0, 1000));
        entities.add(new Pomni("POMNI", 200, 1200));
        entities.add(new Kinger("KINGER", -500, 1500));
        entities.add(new Ragatha("RAGATHA", 400, 1100));
        
        updateMouseLock();
    }

    public void start() {
        new Thread(() -> {
            while (true) {
                if (activeMenu == null) {
                    // THE FIX: Pass 'entities' list so they can chase/play
                    for (Entity e : entities) e.think(entities); 
                }
                repaint();
                try { Thread.sleep(16); } catch (Exception ex) {}
            }
        }).start();
    }

    private void updateMouseLock() {
        if (activeMenu != null) {
            mouseLocked = false;
            setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        } else {
            mouseLocked = true;
            setCursor(getToolkit().createCustomCursor(new java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB), new Point(0, 0), "invisible"));
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        if (mouseLocked && isFocusOwner()) {
            int cx = getWidth() / 2, cy = getHeight() / 2;
            yaw += (e.getX() - cx) * 0.003;
            Point loc = getLocationOnScreen();
            robot.mouseMove(loc.x + cx, loc.y + cy);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        if (com.circus.ai.CircusBrain.IS_TORTURE_MODE) {
            nightmare.render(g2, getWidth(), getHeight(), yaw);
        } else {
            grounds.render(g2, getWidth(), getHeight(), camX, camZ, yaw);
        }
        
        int midX = getWidth() / 2, midY = getHeight() / 2;

        for (Entity en : entities) {
            double dx = en.x - camX, dz = en.z - camZ;
            double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
            double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);

            if (rz < 20) continue;

            int pX = (int)((rx / rz) * 800) + midX;
            int pY = (int)((en.y / rz) * 800) + midY;
            int s = (int)(12000 / rz);

            Color shade = ShaderHandler.applyShading(en.skinColor, rz, Math.max(0.2, 1.0 - (rz/3000)));
            g2.setColor(com.circus.ai.CircusBrain.IS_TORTURE_MODE ? Color.BLACK : shade);
            g2.fillOval(pX - s/2, pY - s/2, s, s);
            
            g2.setColor(Color.WHITE);
            g2.drawString(en.name, pX - s/2, pY - s/2 - 10);
        }

        if (activeMenu != null) activeMenu.draw(g2);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        double s = 50;
        if (activeMenu == null) {
            if (e.getKeyCode() == KeyEvent.VK_W) { camX += Math.sin(yaw) * s; camZ += Math.cos(yaw) * s; }
            if (e.getKeyCode() == KeyEvent.VK_S) { camX -= Math.sin(yaw) * s; camZ -= Math.cos(yaw) * s; }
            if (e.getKeyCode() == KeyEvent.VK_A) { camX -= Math.cos(yaw) * s; camZ += Math.sin(yaw) * s; }
            if (e.getKeyCode() == KeyEvent.VK_D) { camX += Math.cos(yaw) * s; camZ -= Math.sin(yaw) * s; }
            if (e.getKeyCode() == KeyEvent.VK_ESCAPE) activeMenu = new PauseMenu(this);
            if (e.getKeyCode() == KeyEvent.VK_T) activeMenu = new TalkMenu(this);
        } else {
            if (e.getKeyCode() == KeyEvent.VK_ESCAPE) activeMenu = null;
            else activeMenu.key(e);
        }
        updateMouseLock();
    }

    @Override public void mousePressed(MouseEvent e) { if(activeMenu != null) activeMenu.click(e.getX(), e.getY()); else { mouseLocked = true; requestFocusInWindow(); } }
    public void mouseDragged(MouseEvent e) { mouseMoved(e); }
    public void keyReleased(KeyEvent e){} public void keyTyped(KeyEvent e){} public void mouseClicked(MouseEvent e){} public void mouseReleased(MouseEvent e){} public void mouseEntered(MouseEvent e){} public void mouseExited(MouseEvent e){}
}