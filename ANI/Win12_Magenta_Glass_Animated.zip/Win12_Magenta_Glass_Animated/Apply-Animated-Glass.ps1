﻿$ErrorActionPreference = "Stop"
$PackName = "Win12 Magenta Glass Animated"
$Source = Join-Path $PSScriptRoot "Cursors"
$Install = Join-Path $env:LOCALAPPDATA "Win12MagentaGlassAnimated"
$Backup = Join-Path $Install "cursor-backup.reg"
New-Item -ItemType Directory -Force -Path $Install | Out-Null
if (-not (Test-Path $Backup)) { reg export "HKCU\Control Panel\Cursors" $Backup /y | Out-Null }
Copy-Item "$Source\*.ani" $Install -Force
$key = "HKCU:\Control Panel\Cursors"
$map = [ordered]@{Arrow="arrow.ani";Help="help.ani";AppStarting="appstarting.ani";Wait="wait.ani";Crosshair="crosshair.ani";IBeam="ibeam.ani";NWPen="nwpen.ani";No="no.ani";SizeNS="sizens.ani";SizeWE="sizewe.ani";SizeNWSE="sizenwse.ani";SizeNESW="sizenesw.ani";SizeAll="sizeall.ani";UpArrow="uparrow.ani";Hand="hand.ani"}
foreach ($i in $map.GetEnumerator()) { Set-ItemProperty -Path $key -Name $i.Key -Value (Join-Path $Install $i.Value) }
Set-ItemProperty -Path $key -Name "(default)" -Value $PackName
Set-ItemProperty -Path $key -Name "Scheme Source" -Type DWord -Value 1
New-Item -Path "$key\Schemes" -Force | Out-Null
Set-ItemProperty -Path "$key\Schemes" -Name $PackName -Value (($map.Values|%{Join-Path $Install $_}) -join ',')
Add-Type 'using System;using System.Runtime.InteropServices;public class C{[DllImport("user32.dll")]public static extern bool SystemParametersInfo(uint a,uint b,IntPtr c,uint d);}'
[C]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,3)|Out-Null
Write-Host "Animated glass cursors applied. Backup: $Backup" -ForegroundColor Magenta
