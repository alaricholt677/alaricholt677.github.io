
(function(){'use strict';
function Q(q){return window.jQuery?window.jQuery(q):document.querySelectorAll(q)}
function ready(cb){var n=0,t=setInterval(function(){n++;if(typeof nts!=='undefined'&&window.shownotice&&typeof widgets!=='undefined'&&window.jQuery){clearInterval(t);cb()}if(n>180)clearInterval(t)},100)}
ready(function(){
var ALL=[['zerocode','0 Code Widget'],['quicknotes','Quick Notes'],['vfsstats','VFS Stats'],['worldclock','World Clock'],['rssheadlines','News Sources'],['todoPlus','To Do'],['launcherPlus','App Launcher'],['fileSearchPlus','VFS Search'],['clipboardPlus','Clipboard'],['calendarPlus','Calendar'],['registryWidget','Registry Handlers'],['recentFilesWidget','Recent VFS Files'],['storageWidget','VFS Storage'],['commandWidget','Command Box'],['newsMiniWidget','Mini News']];
function html(){return '<p class="tit">添加小组件</p><list class="new">'+ALL.map(function(w){return '<a class="a plus-widget-option-force" onclick="closenotice();widgets.widgets.add(\''+w[0]+'\')">'+w[1]+'</a>'}).join('')+'</list><p class="plus-status">Custom Widget stays hidden: open 0 Code Widget, then click Create.</p>'}
function patchNts(){if(nts&&nts.widgets){nts.widgets.cnt=html(); if(!nts.widgets.btn)nts.widgets.btn=[{type:'cancel',text:'取消',js:'closenotice();'}];}}
function patchOpenNotice(){var list=Q('#notice>.cnt list.new'); if(!list.length)return; list.html(ALL.map(function(w){return '<a class="a plus-widget-option-force" onclick="closenotice();widgets.widgets.add(\''+w[0]+'\')">'+w[1]+'</a>'}).join(''));}
patchNts();
var old=window.shownotice;
window.shownotice=function(name){patchNts();var r=old.apply(window,arguments);if(name==='widgets'){setTimeout(patchOpenNotice,0);setTimeout(patchOpenNotice,50);setTimeout(patchOpenNotice,150)}return r};
// Add a direct helper too, useful from console: Win12PlusShowAllWidgetsPopup()
window.Win12PlusShowAllWidgetsPopup=function(){patchNts();shownotice('widgets');setTimeout(patchOpenNotice,20)};
console.log('Win12 Plus FORCE widget popup patch loaded');
});})();
