package com.world;

import java.io.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public final class BlockStorage {

    // One file with all blocks (simple + reliable)
    // Format (v1):
    // int magic = 0x424C4B31  ("BLK1")
    // int chunkRadius
    // int chunkSize
    // int gridSize
    // for each chunk record (gridSize*gridSize):
    //   int cx, int cz
    //   byte[SIZE*SIZE*SIZE] blocks (x-major, then y, then z)

    private static final int MAGIC_BLK1 = 0x424C4B31;

    public static void save(File file, World world) throws IOException {
        file.getParentFile().mkdirs();

        try (DataOutputStream out = new DataOutputStream(
                new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(file))))) {

            Chunk[][] grid = world.getChunkGrid();

            out.writeInt(MAGIC_BLK1);
            out.writeInt(world.getRadius());
            out.writeInt(Chunk.SIZE);
            out.writeInt(grid.length);

            for (int gz = 0; gz < grid.length; gz++) {
                for (int gx = 0; gx < grid.length; gx++) {
                    Chunk c = grid[gx][gz];

                    out.writeInt(c.cx);
                    out.writeInt(c.cz);

                    for (int x = 0; x < Chunk.SIZE; x++)
                        for (int y = 0; y < Chunk.SIZE; y++)
                            for (int z = 0; z < Chunk.SIZE; z++)
                                out.writeByte(c.voxels[x][y][z].type);

                    c.dirty = false; // saved clean
                }
            }
        }
    }

    public static void load(File file, World world) throws IOException {
        if (!file.exists()) return;

        try (DataInputStream in = new DataInputStream(
                new BufferedInputStream(new GZIPInputStream(new FileInputStream(file))))) {

            int magic = in.readInt();
            if (magic != MAGIC_BLK1) throw new IOException("Unknown blocks.dat format.");

            int radius = in.readInt();
            int size = in.readInt();
            int gridSize = in.readInt();

            if (radius != world.getRadius() || size != Chunk.SIZE) {
                throw new IOException("Save incompatible with current world size.");
            }

            Chunk[][] grid = world.getChunkGrid();
            if (gridSize != grid.length) throw new IOException("Save grid size mismatch.");

            for (int i = 0; i < gridSize * gridSize; i++) {
                int cx = in.readInt();
                int cz = in.readInt();

                Chunk target = findChunkByCoords(grid, cx, cz);
                if (target == null) {
                    // Consume bytes even if chunk not found (keeps stream aligned)
                    for (int x = 0; x < Chunk.SIZE; x++)
                        for (int y = 0; y < Chunk.SIZE; y++)
                            for (int z = 0; z < Chunk.SIZE; z++)
                                in.readByte();
                    continue;
                }

                for (int x = 0; x < Chunk.SIZE; x++)
                    for (int y = 0; y < Chunk.SIZE; y++)
                        for (int z = 0; z < Chunk.SIZE; z++)
                            target.voxels[x][y][z] = new Voxel(in.readByte());

                target.dirty = false;
            }
        }
    }

    private static Chunk findChunkByCoords(Chunk[][] grid, int cx, int cz) {
        for (int gz = 0; gz < grid.length; gz++)
            for (int gx = 0; gx < grid.length; gx++) {
                Chunk c = grid[gx][gz];
                if (c.cx == cx && c.cz == cz) return c;
            }
        return null;
    }
}
