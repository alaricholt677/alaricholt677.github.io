package com.world;

import com.entities.BaseEntity;
import java.awt.Color;

public final class Chunk {

    public static final int SIZE = 16;

    public final int cx, cz;

    public final Voxel[][][] voxels = new Voxel[SIZE][SIZE][SIZE];
    public final byte[][][] light = new byte[SIZE][SIZE][SIZE];

    public final BaseEntity meshEntity = new BaseEntity() { @Override public void tick() {} };

    public boolean loaded = true;
    public boolean dirty = false;

    public Chunk(int cx, int cz) {
        this.cx = cx;
        this.cz = cz;

        for (int x = 0; x < SIZE; x++)
            for (int y = 0; y < SIZE; y++)
                for (int z = 0; z < SIZE; z++) {
                    voxels[x][y][z] = new Voxel(Voxel.AIR);
                    light[x][y][z] = 0;
                }
    }

    public void setWorldPosition() {
        meshEntity.setPosition(cx * SIZE, 0, cz * SIZE);
    }

    public void unloadMesh() {
        var mesh = meshEntity.getMesh();
        mesh.vertices.clear();
        mesh.triangles.clear();
        loaded = false;
    }

    public void markDirty() { dirty = true; }

    // ------------------------------------------------------------
    // LIGHTING
    // ------------------------------------------------------------
    public void rebuildLighting(World world) {

        // Skylight
        for (int x = 0; x < SIZE; x++) {
            for (int z = 0; z < SIZE; z++) {
                int sky = Voxel.LIGHT_MAX;
                for (int y = SIZE - 1; y >= 0; y--) {
                    if (voxels[x][y][z].isSolid()) {
                        sky = 0;
                        light[x][y][z] = 0;
                    } else {
                        light[x][y][z] = (byte) sky;
                    }
                }
            }
        }

        // Emissive
        for (int x = 0; x < SIZE; x++)
            for (int y = 0; y < SIZE; y++)
                for (int z = 0; z < SIZE; z++) {
                    int em = Voxel.emission(voxels[x][y][z].type);
                    if (em > 0) {
                        int wx = cx * SIZE + x;
                        int wz = cz * SIZE + z;
                        world.floodLightFrom(wx, y, wz, em);
                    }
                }
    }

    // ------------------------------------------------------------
    // MESH BUILDING — GROX LOOK, NO LAG
    // ------------------------------------------------------------
    public void rebuildMesh(World world) {
        var mesh = meshEntity.getMesh();
        mesh.vertices.clear();
        mesh.triangles.clear();

        boolean grox = com.init.GroxHelper.isGrox;

        for (int x = 0; x < SIZE; x++)
            for (int y = 0; y < SIZE; y++)
                for (int z = 0; z < SIZE; z++) {

                    Voxel v = voxels[x][y][z];

                    // NORMAL BEHAVIOR: skip air
                    if (!v.isSolid()) continue;

                    // Grox still overrides color
                    Color base = com.init.GroxHelper.getColor(materialColor(v.type), grox);

                    int wx = cx * SIZE + x;
                    int wz = cz * SIZE + z;

                    // Grox mode: still stylized, but NOT brute-force
                    // We keep the Grox aesthetic by rendering "Grox faces"
                    // but only if they are actually visible.
                    boolean top    = world.isAir(wx, y + 1, wz);
                    boolean bottom = world.isAir(wx, y - 1, wz);
                    boolean east   = world.isAir(wx + 1, y, wz);
                    boolean west   = world.isAir(wx - 1, y, wz);
                    boolean south  = world.isAir(wx, y, wz + 1);
                    boolean north  = world.isAir(wx, y, wz - 1);

                    // Grox mode: stylized face rules
                    if (grox) {
                        // Grox aesthetic: render faces that are "exposed" OR "semi-exposed"
                        // but never hidden faces.
                        if (top)    addFace(mesh, world, wx, y + 1, wz, Face.TOP, base);
                        if (bottom) addFace(mesh, world, wx, y,     wz, Face.BOTTOM, base);
                        if (east)   addFace(mesh, world, wx + 1, y, wz, Face.EAST, base);
                        if (west)   addFace(mesh, world, wx,      y, wz, Face.WEST, base);
                        if (south)  addFace(mesh, world, wx, y, wz + 1, Face.SOUTH, base);
                        if (north)  addFace(mesh, world, wx, y, wz,     Face.NORTH, base);
                    } else {
                        // Normal mode: strict occlusion culling
                        if (top)    addFace(mesh, world, wx, y + 1, wz, Face.TOP, base);
                        if (bottom) addFace(mesh, world, wx, y,     wz, Face.BOTTOM, base);
                        if (east)   addFace(mesh, world, wx + 1, y, wz, Face.EAST, base);
                        if (west)   addFace(mesh, world, wx,      y, wz, Face.WEST, base);
                        if (south)  addFace(mesh, world, wx, y, wz + 1, Face.SOUTH, base);
                        if (north)  addFace(mesh, world, wx, y, wz,     Face.NORTH, base);
                    }
                }

        loaded = true;
    }

    private enum Face { TOP, BOTTOM, NORTH, SOUTH, EAST, WEST }

    private void addFace(BaseEntity.Mesh m, World world, int wx, int wy, int wz, Face f, Color base) {

        int sx = wx, sy = wy, sz = wz;
        switch (f) {
            case TOP    -> sy = wy;
            case BOTTOM -> sy = wy - 1;
            case EAST   -> sx = wx;
            case WEST   -> sx = wx - 1;
            case SOUTH  -> sz = wz;
            case NORTH  -> sz = wz - 1;
        }

        int L = world.getLight(sx, sy, sz);
        double lf = lightFactor(L);

        Color c = new Color(
                clamp255((int)(base.getRed()   * lf)),
                clamp255((int)(base.getGreen() * lf)),
                clamp255((int)(base.getBlue()  * lf))
        );

        double lx = wx - cx * SIZE;
        double lz = wz - cz * SIZE;
        double y  = wy;

        int b = m.vertices.size();

        switch (f) {
            case TOP -> {
                v(m, lx,   y, lz);
                v(m, lx,   y, lz+1);
                v(m, lx+1, y, lz+1);
                v(m, lx+1, y, lz);
            }
            case BOTTOM -> {
                v(m, lx,   y, lz);
                v(m, lx+1, y, lz);
                v(m, lx+1, y, lz+1);
                v(m, lx,   y, lz+1);
            }
            case NORTH -> {
                v(m, lx,   y,   lz);
                v(m, lx,   y+1, lz);
                v(m, lx+1, y+1, lz);
                v(m, lx+1, y,   lz);
            }
            case SOUTH -> {
                v(m, lx,   y,   lz);
                v(m, lx+1, y,   lz);
                v(m, lx+1, y+1, lz);
                v(m, lx,   y+1, lz);
            }
            case EAST -> {
                v(m, lx, y,   lz);
                v(m, lx, y,   lz+1);
                v(m, lx, y+1, lz+1);
                v(m, lx, y+1, lz);
            }
            case WEST -> {
                v(m, lx, y,   lz);
                v(m, lx, y+1, lz);
                v(m, lx, y+1, lz+1);
                v(m, lx, y,   lz+1);
            }
        }

        m.triangles.add(new BaseEntity.Triangle(b, b+1, b+2, c));
        m.triangles.add(new BaseEntity.Triangle(b, b+2, b+3, c));
    }

    private void v(BaseEntity.Mesh m, double x, double y, double z) {
        m.vertices.add(new BaseEntity.Vertex(x, y, z));
    }

    private double lightFactor(int L) {
        double t = Math.max(0, Math.min(15, L)) / 15.0;
        return 0.18 + t * 0.82;
    }

    private int clamp255(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    private Color materialColor(byte t) {
        return switch (t) {
            case Voxel.GRASS -> new Color(80, 160, 80);
            case Voxel.DIRT  -> new Color(120, 90, 60);
            case Voxel.STONE -> new Color(110, 110, 110);
            case Voxel.TORCH -> new Color(255, 200, 80);
            default -> Color.MAGENTA;
        };
    }
}
