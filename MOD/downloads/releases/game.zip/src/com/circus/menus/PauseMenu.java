package com.circus.menus;
import com.circus.main.Engine;
import java.awt.*;

public class PauseMenu extends CircusMenu {
    public PauseMenu(Engine engine) {
        // We add to the 'elements' list defined in CircusMenu
        this.elements.add(new Button(540, 300, 200, 40, "RESUME", () -> engine.activeMenu = null));
        this.elements.add(new Button(540, 360, 200, 40, "QUIT GAME", () -> System.exit(0)));
    }

    @Override
    public void draw(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRect(0, 0, 1280, 720);
        g2.setColor(Color.RED);
        g2.setFont(new Font("Arial", Font.BOLD, 50));
        g2.drawString("PAUSED", 540, 200);
        
        for (UIElement e : elements) e.draw(g2);
    }
}