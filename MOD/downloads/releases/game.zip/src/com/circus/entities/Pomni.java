package com.circus.entities;
import java.awt.Color;
import java.util.ArrayList;

public class Pomni extends Entity { // MUST BE 'Pomni'
    public Pomni(String name, double x, double z) {
        super(name, new Color(40, 40, 180), x, z);
    }
    @Override
    public void think(ArrayList<Entity> allEntities) {
        super.think(allEntities);
    }
}