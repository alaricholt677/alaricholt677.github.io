package com.world;

import com.init.GroxHelper;

public class WorldGen {

    /**
     * Professional Voxel Generation
     * Replaces the heightfield logic with direct voxel placement to match 
     * the Chunk.java structure and inject Grox Protocol modifiers.
     */
    public static void fillHeightfield(Chunk c, int seed) {
        // Use Chunk.SIZE (Capitalized) to match the final Chunk.java
        for (int z = 0; z < Chunk.SIZE; z++) {
            for (int x = 0; x < Chunk.SIZE; x++) {
                
                // Calculate world coordinates using Chunk.SIZE
                int wx = c.cx * Chunk.SIZE + x;
                int wz = c.cz * Chunk.SIZE + z;

                // Calculate the height using your FBM noise algorithm
                double n = fbm(wx, wz, seed);
                int h = (int)Math.round(3 + n * 6); // cubby hills
                
                // Clamp height within chunk bounds
                if (h < 1) h = 1;
                if (h >= Chunk.SIZE) h = Chunk.SIZE - 1;

                // Fill voxels based on calculated height
                for (int y = 0; y < Chunk.SIZE; y++) {
                    if (y < h) {
                        // Standard ground (Dirt/Grass)
                        c.voxels[x][y][z] = new Voxel(Voxel.DIRT);
                    } else if (y == h) {
                        // Surface layer
                        c.voxels[x][y][z] = new Voxel(Voxel.GRASS);
                    } else {
                        // Air
                        c.voxels[x][y][z] = new Voxel(Voxel.AIR);
                    }
                }
            }
        }
    }

    private static double fbm(int x, int z, int seed) {
        double f = 0.06;
        double a = 1.0;
        double sum = 0.0;
        double norm = 0.0;

        for (int i = 0; i < 4; i++) {
            sum += valueNoise(x * f, z * f, seed + i * 101) * a;
            norm += a;
            a *= 0.5;
            f *= 2.0;
        }
        return sum / norm;
    }

    private static double valueNoise(double x, double z, int seed) {
        int x0 = fastFloor(x);
        int z0 = fastFloor(z);
        int x1 = x0 + 1;
        int z1 = z0 + 1;

        double tx = x - x0;
        double tz = z - z0;

        double v00 = hash01(x0, z0, seed);
        double v10 = hash01(x1, z0, seed);
        double v01 = hash01(x0, z1, seed);
        double v11 = hash01(x1, z1, seed);

        tx = smoothstep(tx);
        tz = smoothstep(tz);

        double a = lerp(v00, v10, tx);
        double b = lerp(v01, v11, tx);
        return (lerp(a, b, tz) * 2.0 - 1.0);
    }

    private static int fastFloor(double v) {
        int i = (int)v;
        return (v < i) ? (i - 1) : i;
    }

    private static double smoothstep(double t) {
        return t * t * (3.0 - 2.0 * t);
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private static double hash01(int x, int z, int seed) {
        int h = x * 374761393 + z * 668265263 + seed * 1442695041;
        h ^= (h >>> 13);
        h *= 1274126177;
        h ^= (h >>> 16);
        return (h & 0x7fffffff) / (double)0x7fffffff;
    }
}