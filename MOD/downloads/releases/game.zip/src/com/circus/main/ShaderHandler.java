package com.circus.main;
import java.awt.*;

public class ShaderHandler {
    // Atmospheric Fog Color
    private static final Color FOG_COLOR = new Color(20, 0, 40);

    public static Color applyShading(Color base, double z, double lightIntensity) {
        // 1. DEPTH FOG: Fade to FOG_COLOR as Z increases
        double fogFactor = Math.min(1.0, z / 3000.0); 
        int r = (int) (base.getRed() * (1 - fogFactor) + FOG_COLOR.getRed() * fogFactor);
        int g = (int) (base.getGreen() * (1 - fogFactor) + FOG_COLOR.getGreen() * fogFactor);
        int b = (int) (base.getBlue() * (1 - fogFactor) + FOG_COLOR.getBlue() * fogFactor);

        // 2. LIGHTING: Multiply by intensity (simulating a spotlight)
        r = (int)Math.min(255, r * lightIntensity);
        g = (int)Math.min(255, g * lightIntensity);
        b = (int)Math.min(255, b * lightIntensity);

        return new Color(r, g, b);
    }
}