Performance Presets Pack
========================

Pack ID: performance_presets
Version: 1.0.0

Description:
Adds example level option presets for low-end, balanced, high-performance, high-render-distance, and shader-heavy gameplay setups.

This is a starter/template expansion zip for the IRL Simulator Mod Store.
Your current store UI downloads packs into the expansion_packs folder.

Suggested future install flow:
1. Download this zip.
2. Verify pack_manifest.json.
3. Read data/*.json.
4. Import only safe data into your engine.
5. Never run downloaded Java code automatically.
