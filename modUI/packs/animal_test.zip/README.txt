Animal Test Pack with Commands
==============================

This zip includes data/commands.json.
That is the file ExpansionPackLoader must read to register /sheep into ModRegistry.

Install location after download:
  expansion_packs/Animal_Test_Pack.zip

If /mods says no modpack commands loaded, check:
  1. The zip is inside expansion_packs/
  2. The zip contains data/commands.json
  3. ExpansionPackLoader.loadAllInstalledPacks() runs when loading a world
  4. ExpansionPackLoader.readCommands(zip) is called inside loadPack()
