package com.circus.entities;
import java.awt.Color;
import java.util.ArrayList;

public class Kinger extends Entity { // MUST BE 'Kinger'
    public Kinger(String name, double x, double z) {
        super(name, new Color(150, 100, 255), x, z);
    }
    @Override
    public void think(ArrayList<Entity> allEntities) {
        super.think(allEntities);
    }
}