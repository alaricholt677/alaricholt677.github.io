import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Plugin Status");
            frame.setSize(500, 260);
            frame.setLocationRelativeTo(null);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(new Color(20, 20, 20));

            JLabel greet = new JLabel("Welcome, User!", JLabel.CENTER);
            greet.setFont(new Font("Segoe UI", Font.BOLD, 24));
            greet.setForeground(new Color(180, 180, 180));
            panel.add(greet, BorderLayout.NORTH);

            JLabel status = new JLabel("PLUGIN WORKS", JLabel.CENTER);
            status.setFont(new Font("Segoe UI", Font.BOLD, 46));
            status.setForeground(new Color(0, 255, 120));
            panel.add(status, BorderLayout.CENTER);

            frame.add(panel);
            frame.setVisible(true);

            // Call your engine chat push
            callEngineChat();
        });
    }

    private static void callEngineChat() {
        // This is the decoded chat push syntax
        Engine.pushChat("Follower spawned.");
    }
}
