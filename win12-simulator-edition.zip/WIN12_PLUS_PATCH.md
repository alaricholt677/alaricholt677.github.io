# Win12 Plus Full Patch

Adds a localStorage-backed per-user VFS, file handlers, file:/// Edge support, Regedit, PowerShell, EXE Host, UAC-style virtual admin prompt, custom widgets, 0 Code Widget, Copilot local integration, context-menu file operations, shortcuts, move/import-folder flow, virtual app EXEs, and extra RSS news sources.

All execution is virtual/sandboxed inside the web desktop. It does not run real OS commands.


## Fix layer
- User selector now refreshes login UI immediately.
- Clicking the physical Login button removes the overlay after a valid/no PIN login.
- Widget selector de-duplicates entries, including Now Playing.
- Added more real widgets: To Do, App Launcher, VFS Search, Clipboard, Calendar.


## Ultimate completion layer
- Adds explicit handler apps for code, JSON, Office-like files, archives, and generic files.
- Extends the registry to many common extensions.
- Makes Open with show all handler apps.
- Adds more widgets: Registry Handlers, Recent VFS Files, VFS Storage, Command Box, Mini News.
- Seeds sample JSON/code/archive files into the VFS.


## Account settings layer
- Adds Settings > Account page.
- Change current account username.
- Change/remove PIN/password.
- Create account.
- Delete selected account and its localStorage VFS/config data, while preventing deletion of the last account.


## Widget popup completion layer
- The Add Widgets popup now lists every new widget added by the Plus patch.
- It de-duplicates existing entries.
- The hidden Custom Widget handler remains hidden and is still only created from 0 Code Widget > Create.


## Force widget popup fix
- Replaces nts.widgets.cnt directly, which is what shownotice('widgets') actually renders into #notice>.cnt.
- Also patches #notice>.cnt list.new after the popup opens.
