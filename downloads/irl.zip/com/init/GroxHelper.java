package com.init;

import java.awt.Color;
import java.io.*;
import java.nio.file.*;
import main.Main;

public class GroxHelper {
    public static boolean isGrox = false;

    public static void initialize() {
        if (Main.USER_NAME != null && Main.USER_NAME.equalsIgnoreCase("Grox")) {
            isGrox = true;
        }
    }

    public static Color getColor(Color c, boolean isSky) {
        if (!isGrox) return c;
        if (isSky) return new Color(255, 182, 193); // Pink
        if (c.getGreen() > c.getRed()) return new Color(128, 0, 128); // Purple
        return c;
    }

    public static double[] getSpawn(double px, double py, double pz, double yaw) {
        if (!isGrox) return null;
        double x = px + Math.sin(yaw) * 0.8;
        double z = pz + Math.cos(yaw) * 0.8;
        return new double[]{x, py, z};
    }

    // Match the naming used in EntitiesAliveSave
    public static double[] getKissingPos(double x, double y, double z, double yaw) {
        return getSpawn(x, y, z, yaw);
    }
}