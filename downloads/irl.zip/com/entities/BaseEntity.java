package com.entities;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseEntity {

    public static final class Vertex {
        public double x, y, z;
        public Vertex(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
    }

    public static final class Triangle {
        public int v1, v2, v3;
        public Color color;
        public Triangle(int v1, int v2, int v3, Color color) {
            this.v1 = v1; this.v2 = v2; this.v3 = v3; this.color = color;
        }
    }

    public static final class Mesh {
        public final List<Vertex> vertices = new ArrayList<>();
        public final List<Triangle> triangles = new ArrayList<>();
    }

    protected double x, y, z;
    protected double vX, vY, vZ;

    protected final Mesh mesh = new Mesh();

    public double getX() { return x; }
    public double getY() { return y; }
    public double getZ() { return z; }

    public void setPosition(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }

    public Mesh getMesh() { return mesh; }

    public void applyGravity() {
        vY += 0.02;
        y += vY;

        if (y > 0) {
            y = 0;
            vY = 0;
        }
    }

    public void integrateVelocity() {
        x += vX;
        y += vY;
        z += vZ;
    }

    public void tick() {
        applyGravity();
        integrateVelocity();
    }
}
