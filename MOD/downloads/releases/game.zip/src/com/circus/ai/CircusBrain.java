package com.circus.ai;

public class CircusBrain {
    private static int insultCount = 0;
    public static boolean IS_TORTURE_MODE = false;

    private static final String[] BLACKLIST = {"stupid", "idiot", "hate", "ugly", "garbage", "trash"};

    public static String getResponse(String entityName, String userMsg, String userName) {
        String msg = userMsg.toLowerCase();

        // 1. MONITOR FOR INSULTS
        for (String word : BLACKLIST) {
            if (msg.contains(word)) insultCount++;
        }

        // 2. TRIGGER THE NIGHTMARE
        if (insultCount >= 3 && !IS_TORTURE_MODE) {
            IS_TORTURE_MODE = true;
            return "CAINE: ... ... ... Oho! I strictly... FORBID... that tone! I have... 000... REPLACED_REALITY! WELCOME TO THE CELLAR, " + userName.toUpperCase() + "!";
        }

        if (IS_TORTURE_MODE) {
            return "CAINE: [STATIC] ... 01101000 01100101 01101100 01101100 ... [STATIC]";
        }

        // Standard logic for non-torture mode
        if (msg.contains("exit")) return "CAINE: There is no exit, only the show!";
        return "CAINE: Let's keep things... WHEELING... along!";
    }
}