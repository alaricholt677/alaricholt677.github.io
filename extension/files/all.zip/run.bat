@echo off
setlocal

echo %1 > "C:\all\path.txt"

"%USERPROFILE%\AppData\Local\Programs\Python\Python313\pythonw.exe" -u -B "C:\all\run.py"

endlocal
exit /b
