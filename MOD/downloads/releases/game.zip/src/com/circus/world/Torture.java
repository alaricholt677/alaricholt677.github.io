package com.circus.world;
import java.awt.*;
import java.util.Random;

public class Torture {
    private Random rand = new Random();

    public void render(Graphics2D g2, int width, int height, double yaw) {
        // 1. BLOOD-RED SKYBOX
        g2.setColor(new Color(20, 0, 0));
        g2.fillRect(0, 0, width, height);

        // 2. VIBRATING GEOMETRY (The Nightmare)
        g2.setStroke(new BasicStroke(2));
        for (int i = 0; i < 100; i++) {
            int x = rand.nextInt(width);
            int y = rand.nextInt(height);
            int w = rand.nextInt(200);
            
            // Random static glitches
            g2.setColor(new Color(255, 0, 0, rand.nextInt(100) + 50));
            g2.drawLine(x, y, x + w, y + (int)(Math.sin(yaw) * 50));
        }

        // 3. THE "VOID" EYE
        g2.setColor(Color.WHITE);
        g2.fillOval(width/2 - 50 + rand.nextInt(10), height/2 - 50 + rand.nextInt(10), 100, 100);
        g2.setColor(Color.BLACK);
        g2.fillOval(width/2 - 20, height/2 - 20, 40, 40);

        // 4. TEXT OVERLAY
        g2.setFont(new Font("Monospaced", Font.BOLD, 100));
        g2.setColor(new Color(255, 0, 0, 50));
        g2.drawString("REDACTED", rand.nextInt(width), rand.nextInt(height));
    }
}