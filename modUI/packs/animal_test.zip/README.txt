Animal Test Pack
================

This is the full animal_test.zip mod pack for IRL Simulator.

It contains:
- pack_manifest.json
- data/info.json
- data/animals.json
- sheep command docs
- engine hook docs

Upload this file to:
  modUI/packs/animal_test.zip

Then make sure ui.store points to:
  https://alaricholt677.github.io/modUI/packs/animal_test.zip

After downloading it in-game, reload/load a world so ExpansionPackLoader reads it.
