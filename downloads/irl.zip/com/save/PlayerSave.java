package com.save;

import java.io.*;

public final class PlayerSave {

    public static final class PlayerData {
        public double x, y, z;
        public int selectedSlot;
        public byte slot0, slot1, slot2, slot3, slot4, slot5, slot6, slot7, slot8;
    }

    public static void save(File file, PlayerData d) throws IOException {
        file.getParentFile().mkdirs();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeDouble(d.x);
            out.writeDouble(d.y);
            out.writeDouble(d.z);
            out.writeInt(d.selectedSlot);

            out.writeByte(d.slot0);
            out.writeByte(d.slot1);
            out.writeByte(d.slot2);
            out.writeByte(d.slot3);
            out.writeByte(d.slot4);
            out.writeByte(d.slot5);
            out.writeByte(d.slot6);
            out.writeByte(d.slot7);
            out.writeByte(d.slot8);
        }
    }

    public static PlayerData load(File file) throws IOException {
        PlayerData d = new PlayerData();
        if (!file.exists()) return d;

        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            d.x = in.readDouble();
            d.y = in.readDouble();
            d.z = in.readDouble();
            d.selectedSlot = in.readInt();

            d.slot0 = in.readByte();
            d.slot1 = in.readByte();
            d.slot2 = in.readByte();
            d.slot3 = in.readByte();
            d.slot4 = in.readByte();
            d.slot5 = in.readByte();
            d.slot6 = in.readByte();
            d.slot7 = in.readByte();
            d.slot8 = in.readByte();
        }
        return d;
    }
}
