package com.circus.entities;
import java.awt.Color;
import java.util.ArrayList;

public class Ragatha extends Entity { // MUST BE 'Ragatha'
    public Ragatha(String name, double x, double z) {
        super(name, new Color(180, 40, 40), x, z);
    }
    @Override
    public void think(ArrayList<Entity> allEntities) {
        super.think(allEntities);
    }
}