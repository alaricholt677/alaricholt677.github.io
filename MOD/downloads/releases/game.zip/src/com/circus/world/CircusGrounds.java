package com.circus.world;

import com.circus.main.ShaderHandler;
import java.awt.*;

public class CircusGrounds {

    public void render(Graphics2D g2, int width, int height,
                       double camX, double camZ, double yaw) {

        int cx = width / 2;
        int cy = height / 2;

        // 1. SKYBOX
        g2.setPaint(new GradientPaint(
                0, 0, new Color(15, 0, 25),
                0, cy, new Color(40, 0, 60)
        ));
        g2.fillRect(0, 0, width, height);

        // 2. GROUND + STRUCTURES
        for (int z = 0; z <= 5000; z += 250) {
            for (int x = -2500; x <= 2500; x += 250) {

                // World → camera
                double dx = x - camX;
                double dz = z - camZ;

                // Rotate by yaw
                double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
                double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);

                if (rz < 50) continue;

                // Perspective
                int px = (int)((rx / rz) * 800) + cx;
                int py = (int)((400 / rz) * 800) + cy;
                int size = (int)(15000 / rz);

                // Central ring at (0, 1000)
                double distToRing = Math.sqrt(x * x + Math.pow(z - 1000, 2));
                if (distToRing < 400) {
                    Color base = new Color(100, 0, 0);
                    Color shaded = ShaderHandler.applyShading(base, rz, 1.2);
                    g2.setColor(shaded);
                    g2.fillOval(px - size/2, py - size/4, size, size/2);
                    continue;
                }

                // Bleachers
                if (Math.abs(x) > 800 || z > 2000) {
                    int bH = (int)((Math.abs(x) * 0.1) * (800.0 / rz));
                    Color base = new Color(60, 40, 30);
                    Color shaded = ShaderHandler.applyShading(base, rz, 0.5);
                    g2.setColor(shaded);
                    g2.fillRect(px - size/2, py - bH, size, bH);
                    g2.setColor(Color.BLACK);
                    g2.drawRect(px - size/2, py - bH, size, bH);
                }
            }
        }

        // 3. TENT POLES
        renderPole(g2, -600, 1000, camX, camZ, yaw, cx, cy);
        renderPole(g2,  600, 1000, camX, camZ, yaw, cx, cy);
    }

    private void renderPole(Graphics2D g2, int x, int z,
                            double camX, double camZ, double yaw,
                            int midX, int midY) {

        double dx = x - camX;
        double dz = z - camZ;

        double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
        double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);

        if (rz < 50) return;

        int px = (int)((rx / rz) * 800) + midX;
        int py = midY;
        int pW = (int)(5000 / rz);
        int pH = (int)(40000 / rz);

        Color base = new Color(180, 180, 180);
        Color shaded = ShaderHandler.applyShading(base, rz, 0.8);
        g2.setColor(shaded);
        g2.fillRect(px - pW/2, py - pH, pW, pH);
    }
}
