package com.config;

import java.io.*;
import java.nio.file.Files;
import java.util.*;

public final class LevelManager {

    public static final File CONFIGS_DIR = new File("configs");

    public static final class LevelEntry {
        public final String name;
        public final File dir;
        public LevelEntry(String name, File dir) { this.name = name; this.dir = dir; }
    }

    public static List<LevelEntry> listLevels() {
        ensureConfigs();
        File[] dirs = CONFIGS_DIR.listFiles(File::isDirectory);
        if (dirs == null) return List.of();

        List<LevelEntry> out = new ArrayList<>();
        for (File d : dirs) {
            File nameTxt = new File(d, "name.txt");
            String name = d.getName();
            if (nameTxt.exists()) {
                try { name = Files.readString(nameTxt.toPath()).trim(); } catch (Exception ignored) {}
            }
            out.add(new LevelEntry(name, d));
        }
        out.sort(Comparator.comparing(a -> a.name.toLowerCase()));
        return out;
    }

    public static File createLevel(String levelName) throws IOException {
        ensureConfigs();

        String safe = sanitize(levelName);
        File dir = new File(CONFIGS_DIR, safe);
        if (dir.exists()) throw new IOException("Level already exists: " + safe);

        if (!dir.mkdirs()) throw new IOException("Failed to create: " + dir);

        new File(dir, "humanalive").mkdirs();
        new File(dir, "blockdata").mkdirs();
        new File(dir, "playerpos").mkdirs();

        Files.writeString(new File(dir, "name.txt").toPath(), levelName.trim());
        new LevelOptions().save(new File(dir, "options.txt"));

        return dir;
    }

    public static void deleteLevel(File dir) throws IOException {
        if (dir == null || !dir.exists()) return;
        deleteRecursive(dir);
    }

    public static void renameLevel(File dir, String newName) throws IOException {
        if (dir == null || !dir.exists()) return;
        Files.writeString(new File(dir, "name.txt").toPath(), newName.trim());
    }

    public static LevelOptions loadOptions(File dir) {
        return LevelOptions.load(new File(dir, "options.txt"));
    }

    public static void saveOptions(File dir, LevelOptions o) {
        o.save(new File(dir, "options.txt"));
    }

    private static void ensureConfigs() {
        if (!CONFIGS_DIR.exists()) CONFIGS_DIR.mkdirs();
    }

    private static String sanitize(String s) {
        s = s.trim();
        if (s.isEmpty()) s = "NewWorld";
        return s.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private static void deleteRecursive(File f) throws IOException {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        if (!f.delete()) throw new IOException("Failed to delete: " + f);
    }
}
