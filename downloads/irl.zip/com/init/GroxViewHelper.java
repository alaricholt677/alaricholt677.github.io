package com.init;

import java.awt.Color;
import main.Main;

public class GroxViewHelper {
    public static Color applyGroxFilters(Color original, boolean isSky) {
        if (!"Grox".equalsIgnoreCase(Main.USER_NAME)) return original;

        if (isSky) return new Color(255, 182, 193); // Pink Sky

        // Swap Green to Purple
        if (original.getGreen() > original.getRed() && original.getGreen() > original.getBlue()) {
            return new Color(128, 0, 128); 
        }
        return original;
    }
}