More Blocks Expansion
=====================

Pack ID: more_blocks
Version: 1.0.0

Description:
Adds a large starter set of decorative and survival blocks for testing new building styles. Includes colored blocks, metal blocks, stone variants, glowing blocks, and simple furniture test blocks.

This is a starter/template expansion zip for the IRL Simulator Mod Store.
Your current store UI downloads packs into the expansion_packs folder.

Suggested future install flow:
1. Download this zip.
2. Verify pack_manifest.json.
3. Read data/*.json.
4. Import only safe data into your engine.
5. Never run downloaded Java code automatically.
