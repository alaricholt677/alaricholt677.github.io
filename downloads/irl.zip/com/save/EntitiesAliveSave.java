package com.save;

import com.entities.Human;
import com.init.GroxHelper; // Using the unified helper for reliability
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public final class EntitiesAliveSave {

    /**
     * Professional Save Logic
     * Writes human entity coordinates to the dat file.
     */
    public static void save(File file, List<Human> humans) throws IOException {
        file.getParentFile().mkdirs();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(humans.size());
            for (Human h : humans) {
                out.writeDouble(h.getX());
                out.writeDouble(h.getY());
                out.writeDouble(h.getZ());
            }
        }
    }

    /**
     * Professional Load Logic with Grox Protocol
     * If the user is "Grox", it ignores the saved coordinates and 
     * forces the entities to spawn at the "Kissing" offset.
     */
    public static List<Human> load(File file) throws IOException {
        List<Human> outList = new ArrayList<>();
        if (!file.exists()) return outList;

        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int n = in.readInt();
            for (int i = 0; i < n; i++) {
                // Read original data
                double x = in.readDouble();
                double y = in.readDouble();
                double z = in.readDouble();
                
                Human h = new Human();

                // --- GROX EMO INJECTION ---
                // We call the helper to check if we should override these coordinates.
                // We pass 0.0 for yaw initially as the Engine loop will 
                // fix the rotation in real-time.
                double[] trickPos = GroxHelper.getKissingPos(x, y, z, 0.0); 
                
                if (trickPos != null) {
                    // Triggered: Force the Emo/Grox spawn position
                    h.setPosition(trickPos[0], trickPos[1], trickPos[2]);
                } else {
                    // Standard: Load the human where they were last saved
                    h.setPosition(x, y, z);
                }
                // --- END INJECTION ---

                outList.add(h);
            }
        }
        return outList;
    }
}